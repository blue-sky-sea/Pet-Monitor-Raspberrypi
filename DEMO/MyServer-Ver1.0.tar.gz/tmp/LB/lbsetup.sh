#!/bin/bash

# 使うバージョンのファイルをここに指定する
VER=2.2
FILE=haproxy-2.2.6

MYSERVER_TOP=$1
if [ "x$MYSERVER_TOP" = "x" ]
then
    exit 1
fi

URL=http://www.haproxy.org/download/${VER}/src/${FILE}.tar.gz

pushd $MYSERVER_TOP/LB
if [ -x haproxy ]; then
    echo "Already installed HAProxy"
else
    echo "Installing HAProxy. This may take long time. Please Wait..."
    echo "  - downloading..."
    pushd $MYSERVER_TOP/download
    wget -nc -q $URL
    popd

    echo "  - installing development package..."
    $SUDO apt-get install -y libpcre3 libpcre3-dev

    echo "  - building..."
    tar zxf $MYSERVER_TOP/download/$FILE.tar.gz
    cd $FILE
    make TARGET=linux-glibc USE_PCRE=1 >& haproxy_make.log
    cp -p haproxy $MYSERVER_TOP/LB/
fi
popd



