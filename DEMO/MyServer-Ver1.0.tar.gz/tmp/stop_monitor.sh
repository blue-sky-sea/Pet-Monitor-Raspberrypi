#!/bin/bash
#
# ペット見守りモニタ停止スクリプト
#

. ./myserver.env
. ./cmd
. ./goenv.sh
. ./nodeenv.sh
. ./pythonenv.sh


## MONITOR
if [ "$USE_PETWATCHER" = "YES" ];then
    pushd $MYSERVER_ROOT/PetWatcher/MONITOR

    echo "Stop distance.py"
    pid=`ps -af | grep python | grep 'distance.py' | awk '{print($2)}'`
    if [ "x$pid" != "x" ]; then
	$SUDO kill -9 $pid
    fi

    echo "Stop picture.py"
    pid=`ps -af | grep python | grep 'picture.py' | awk '{print($2)}'`
    if [ "x$pid" != "x" ]; then
	$SUDO kill -9 $pid
    fi

    echo "Stop sensor.py"
    pid=`ps -af | grep python | grep 'sensor.py' | awk '{print($2)}'`
    if [ "x$pid" != "x" ]; then
	$SUDO kill -9 $pid
    fi
    
    popd
fi
