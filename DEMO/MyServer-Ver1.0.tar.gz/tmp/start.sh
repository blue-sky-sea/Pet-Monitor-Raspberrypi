#!/bin/bash
#
# Myサーバ起動スクリプト
#

. ./myserver.env
. ./cmd
. ./goenv.sh
. ./nodeenv.sh
. ./pythonenv.sh

# Storage Server
if [ "$USE_STORAGE" = "YES" ];then
    pushd $MYSERVER_ROOT/Services/Storage
    nohup ./MyStorageServer &
    popd
fi

# LB
if [ "$USE_LB" = "YES" ];then
    echo "start LB"
    $SUDO $MYSERVER_ROOT/LB/haproxy -f $MYSERVER_ROOT/LB/myserver_lb.cfg -p $MYSERVER_ROOT/LB/haproxy.pid
fi

# MQTT Broker
if [ "$USE_MQTT" = "YES" ];then
    pushd $MYSERVER_ROOT/Services/IoT/MQTTBroker
    if [ -x emq-relx/_build/emqx/rel/emqx/bin/emqx ]; then
	emq-relx/_build/emqx/rel/emqx/bin/emqx start
    elif [ -x emq-relx/_rel/emqx/bin/emqx ]; then
	emq-relx/_rel/emqx/bin/emqx start
    fi
    popd
fi


# IoT
pushd $MYSERVER_ROOT/Services/IoT
if [ "$USE_IOT_DISTRIBUTOR" = "YES" ];then
    pushd MessageDistributor
    nohup ./MessageDistributor &
    popd
fi
if [ "$USE_IOT_COLLECTOR" = "YES" ];then
    pushd MessageCollector
    nohup ./MessageCollector &
    popd
fi
if [ "$USE_IOT_AUTOMATE" = "YES" ];then
    pushd Automate
    nohup ./Automate &
    popd
fi
popd

# APP
## FileView
if [ "$USE_FILEVIEW" = "YES" ];then
    pushd $MYSERVER_ROOT/APP/FileView
    node fileview.js &
    popd
fi

# PetWatcher
## APP
if [ "$USE_PETWATCHER" = "YES" ];then
    pushd $MYSERVER_ROOT/PetWatcher/APP
    node petwatcher.js &
    popd
fi





