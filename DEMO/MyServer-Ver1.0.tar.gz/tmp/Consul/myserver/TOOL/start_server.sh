#!/bin/bash

. coordinator.env

. MYINFO

JOIN_TO=""
if [ "x$OTHERS" != "x" ] ; then
    IFS=$','
    for srv in $OTHERS
    do
	JOIN_TO="$JOIN_TO -retry-join=$srv"
    done
fi

echo $JOIN_TO

bin/consul agent -server -bootstrap-expect=3 -data-dir `pwd`/server_data -node=consul-${NAME} -bind=${ME} -client=${ME} -retry-join=${NO2} -retry-join=${NO3} -ui > `pwd`/server/consul.log-`date "+%Y%m%d%H%M%S"` 2>&1 &
