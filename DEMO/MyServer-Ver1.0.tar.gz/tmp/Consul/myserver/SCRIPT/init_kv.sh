#!/bin/bash

. ENV

CONSUL=Coordinator/bin/consul
SERVER=$ME
PORT=8500

function create_entry () {
    echo "ARG:$1 $2"
    KEY=$1
    VAL=$2
    $CONSUL kv put -http-addr=$SERVER:$PORT $KEY $VAL
}

SERVICE_TOP='MyServer/Service'
VER="Ver0.5"

create_entry  ${SERVICE_TOP}/LB $VER
create_entry  ${SERVICE_TOP}/MQTT $VER
create_entry  ${SERVICE_TOP}/DISTRIBUTOR $VER
create_entry  ${SERVICE_TOP}/COLLECTOR $VER
create_entry  ${SERVICE_TOP}/AUTOMATE $VER
create_entry  ${SERVICE_TOP}/STORAGE-1 $VER
create_entry  ${SERVICE_TOP}/STORAGE-2 $VER

NODE_TOP='MyServer/Node'
VER="Ver0.5"
create_entry  ${NODE_TOP}/srv1 $VER
create_entry  ${NODE_TOP}/srv2 $VER
create_entry  ${NODE_TOP}/srv3 $VER

