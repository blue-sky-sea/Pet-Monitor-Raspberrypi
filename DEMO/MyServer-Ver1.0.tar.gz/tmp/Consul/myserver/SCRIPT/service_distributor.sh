#!/bin/bash

. ENV

. service_common.sh

MYNAME=consul-$NAME
MYIP=$ME
API=$MYIP:8500

SERVICE=DISTRIBUTOR
SERVICE_DEF=service_distributor.json

function start_distributor () {
    echo "start Distributor"
    pushd $MYSERVER_ROOT/Services/IoT/MessageDistributor
    nohup ./MessageDistributor &
    popd
}

SVC_STATUS=`get_service_status $API $SERVICE`
echo $SVC_STATUS

if [ "$SVC_STATUS" = "passing" ] ; then
    echo "Service is Running."
    exit 0
elif  [ "$SVC_STATUS" != "critical" ] ; then
    echo "NO Service."
    exit 0
fi

SVC_NODE=`get_service_node $API $SERVICE`
echo $SVC_NODE

if [ $SVC_NODE = $MYNAME ] ; then
    # サービスを起動
    start_distributor
    sleep 11
    exit 0
fi


NODE_STATUS=`get_node_status $API $SVC_NODE`
echo $NODE_STATUS

if [ $NODE_STATUS = "passing" ] ; then
    echo "Can't Start My node"
    exit 0
fi

# サービスを起動するノードを決める
#node=`get_node_run_service $API`
#今はこれはサポートしない

# 元のサービス情報を削除
deregister_service ${SVC_NODE}.node.consul:8500 ${SERVICE}-id

# サービスの動作ノードを自身としてサービスの登録情報をアップデート
register_service $API $SERVICE_DEF

# サービス起動
start_distributor

# サービスの状態更新を待って終了する
sleep 11

exit 0