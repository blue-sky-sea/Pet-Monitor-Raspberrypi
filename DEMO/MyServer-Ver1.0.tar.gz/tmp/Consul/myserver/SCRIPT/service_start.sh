#!/bin/bash

. ENV


#  サービス
SERVICE=$1
CMD=$2


# 自ノード名
MYNODE=$NAME
API=$MYNODE:8500


# lockコマンドはロックを取得したら指定コマンドを実行する機能
#consul lock -n=1 -timeout=60s -verbose  -http-addr=$API MyServer/Service/LB "echo LOCK;sleep 20;echo UNLOCK"
consul lock -n=1 -timeout=60s -verbose  -http-addr=$API $SERVICE $CMD

