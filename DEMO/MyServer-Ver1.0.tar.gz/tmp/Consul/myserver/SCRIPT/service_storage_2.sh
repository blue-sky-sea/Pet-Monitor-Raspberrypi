#!/bin/bash

. ENV

. service_common.sh

MYNAME=consul-$NAME
MYIP=$ME
API=$MYIP:8500

SERVICE=STORAGE_2
SERVICE_DEF=service_storage_2.json

function start_storage () {
    echo "start Storage_2"
    pushd $MYSERVER_ROOT/Services/Storage
    nohup ./MyStorageServer &
    popd
}

SVC_STATUS=`get_service_status $API $SERVICE`
echo $SVC_STATUS

if [ "$SVC_STATUS" = "passing" ] ; then
    echo "Service is Running."
    exit 0
elif  [ "$SVC_STATUS" != "critical" ] ; then
    echo "NO Service."
    exit 0
fi

SVC_NODE=`get_service_node $API $SERVICE`
echo $SVC_NODE

if [ $SVC_NODE = $MYNAME ] ; then
    # サービスを起動
    start_storage
    sleep 11
    exit 0
fi

exit 0