#!/bin/bash

. ENV

CONSUL=consul

# サービスを登録する：register_service <API-URL> <サービス名>
function register_service () {
    API=$1
    SERVICE=$2
    curl -s --request PUT --data @$SERVICE http://$API/v1/agent/service/register
}

# サービスを登録解除する：deregister_service <API-URL> <サービスID>
function deregister_service () {
    API=$1
    SERVICE_ID=$2
    $CONSUL services deregister -http-addr=$API -id=$SERVICE_ID
}

# サービスの状態を返す：get_service_status <API-URL> <サービス名>
function get_service_status () {
    API=$1
    SERVICE=$2

    STATUS=`curl -s http://$API/v1/health/service/$SERVICE | jq .[0].Checks | jq "map(select( .[\"ServiceName\"] == \"$SERVICE\"))" | jq .[0].Status`
    STATUS=${STATUS//\"/}
    echo $STATUS
}

# サービスの起動ノードを返す：get_service_node <API-URL> <サービス名>
function get_service_node () {
    API=$1
    SERVICE=$2

    NODE=`curl -s http://$API/v1/health/service/$SERVICE | jq .[0].Service.Address`
    NODE=${NODE//\"/}
    NODE=${NODE//\.node\.consul/}
    echo $NODE
}

# 指定ノードの状態を返す：get_node_status <API-URL> <ノード名>
function get_node_status () {
    API=$1
    NODE=$2

    STATUS=`curl -s http://$API/v1/health/node/$NODE | jq .[0].Status`
    STATUS=${STATUS//\"/}
    echo $STATUS
}

# サービスを起動するノードを返す：get_node_run_service <API-URL>
function get_node_run_service () {
    API=$1

    USER="tsuyo"
    PASS="tsuyo00"

    svc_num=0
    node=""
    # 動作しているノードの中で起動サービス数が少ないものを選択
    IFS=$'\n'
    for rec in `consul members -http-addr=$API | grep -i consul-srv`
    do
	srv=`echo $rec | awk '{print($1)}'`
	sts=`echo $rec | awk '{print($3)}'`
	if [ "$sts" = "alive" ] ; then
	    echo alive
	    #num=`ps -aex  | grep 'MyServer/' | wc -l`
	    num=`sshpass -p ${PASS} ssh ${USER}@${srv}.node.consul bash -c "ps -aex  | grep 'MyServer/' | wc -l"`
	    echo $num
	    if [ $((num)) -lt $svc_num ] ;  then
		echo "set $num, $srv"
		svc_num = $((num))
		node = $srv
	    fi
        fi
    done

    echo $srv
}


