#!/bin/bash

. ENV

API=$ME:8500

CONSUL=consul


function event_add () {
    API=$1
    SERVICE=$2
    CMD=$3
    nohup $CONSUL watch -http-addr=$API -type=service -service=$SERVICE "`pwd`/event_restart.sh $API $SERVICE `pwd`/$CMD" > $SERVICE.event.log &
}

event_add $API LB service_lb.sh
event_add $API MQTT service_mqtt.sh
event_add $API AUTOMATE service_automate.sh
event_add $API COLLECTOR service_collector.sh
event_add $API DISTRIBUTOR service_distributor.sh
event_add $API STORAGE_1 service_storage_1.sh
event_add $API STORAGE_2 service_storage_2.sh
