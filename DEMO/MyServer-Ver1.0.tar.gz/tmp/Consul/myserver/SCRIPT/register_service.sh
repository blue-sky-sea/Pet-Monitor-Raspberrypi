#!/bin/bash

. ENV

. service_common.sh

#初期のサービス登録
API=$ME:8500

if [ "$NAME" = "srv1" ] ; then
    echo "register Service on SRV1"
    register_service $API service_mqtt.json
    register_service $API service_lb.json
fi

if [ "$NAME" = "srv2" ] ; then
    echo "register Service on SRV2"
    register_service $API service_storage_1.json
    register_service $API service_distributor.json
    register_service $API service_collector.json
fi

if [ "$NAME" = "srv3" ] ; then
    echo "register Service on SRV3"
    register_service $API service_storage_2.json
    register_service $API service_automate.json
fi

