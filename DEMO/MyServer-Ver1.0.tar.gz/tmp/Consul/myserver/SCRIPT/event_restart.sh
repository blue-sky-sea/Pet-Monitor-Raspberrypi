#!/bin/bash -x 

. ENV

echo "event_restart.sh Start!"

API=$1
SERVICE=$2
CMD=$3

CONSUL=consul

# lockコマンドはロックを取得したら指定コマンドを実行する機能
$CONSUL lock -n=1 -timeout=60s -verbose  -http-addr=$API MyServer/Service/$SERVICE $CMD

echo "event_restart.sh Finish!"



