#!/bin/bash

# 初期化スクリプト

. ./config

mkdir -p $INFO_DIR
mkdir -p $MON_DIR

cp -p info $INFO_DIR/
cp -p status $INFO_DIR/

