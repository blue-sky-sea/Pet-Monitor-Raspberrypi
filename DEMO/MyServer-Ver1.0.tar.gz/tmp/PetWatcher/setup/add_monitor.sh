#!/bin/bash

# モニタ装置を登録するスクリプト
# ex) ./add_monitor.sh RASPI_MON 192.168.2.20 "モニタ装置その１" "猫の部屋"
# 半角スペースは指定できない。全角スペースはOK。

. ./config


CMD=`basename $0`

if [ $# -lt 4 ]
then
    echo "Usage: $CMD <ID> <IP> <NAME> <PLACE> [INFO]"
    exit 1
fi

MON_ID=$1
MON_IP=$2
MON_NAME="$3"
MON_PLACE="$4"
if [ $# == 5 ]
then
    MON_INFO="$5"
else
    MON_INFO="ペットの様子を見守る装置"
fi


echo $MON_ID
echo $MON_IP
echo $MON_NAME
echo $MON_PLACE
echo $MON_INFO

# ファイルがある場合はエラー
if [ -e ${MON_DIR}/${MON_ID} ]
then
    echo "Already exist."
    exit 1
fi


# ファイルを作成する
cat mon.json | sed s/__ID__/\"${MON_ID}\"/g		\
    	| sed s/__IP__/\"${MON_IP}\"/g		\
    	| sed s/__NAME__/\"${MON_NAME}\"/g		\
	| sed s/__PLACE__/\"${MON_PLACE}\"/g	\
    	| sed s/__INFO__/\"${MON_INFO}\"/g		\
		> ${MON_DIR}/$MON_ID


exit 0







