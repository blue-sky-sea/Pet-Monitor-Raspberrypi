#!/usr/bin/env python                                                                                                                                                    
# -*- coding: utf-8 -*-    


import sys



if len(sys.argv) < 3:
    print('Usage: find_difference.py <prev> <image> <prefix>')
    sys.exit(99)

print("do find_difference.py")


# 引数の取得                                                                                                                                                         
prev_file = sys.argv[1]
image_file = sys.argv[2]
prefix = sys.argv[3]

print("<prev>", prev_file)
print("<image>", image_file)
print("prefix>", prefix)

if prev_file == "NONE":
    print('There is NO previous Image.')
    

print("doone find_difference.py")

if prev_file == image_file:
    sys.exit(1)
else:
    sys.exit(0)
