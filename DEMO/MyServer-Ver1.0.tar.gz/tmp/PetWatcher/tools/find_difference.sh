#!/bin/bash

# 設定ファイル読み込み
. ${MYSERVER_ROOT}/PetWatcher/tools/CONFIG

echo "START: `date`" >> $LOGFILE
env >> $LOGFILE

if [ $# -ne 2 ]
then
    echo "Usage: `basename $0` <data store> <file>"
    exit 1
fi

DATA_STORE=$1
FILE=$2

# PIDを使って作業ディレクトリを作成
MYDIR=$$
TMP_DIR=$WORK_DIR/$MYDIR

mkdir -p $WORK_DIR
mkdir -p $TMP_DIR

echo "TARGET: \"$DATA_STORE\" \"$FILE\"" >> $LOGFILE
echo "WORK: \"$TMP_DIR\"" >> $LOGFILE
echo "STORAGE SERVER: \"$STORAGE_SERVER\"" >> $LOGFILE
echo "IMAGE FILE: \"$IMAGEFILE\"" >> $LOGFILE
echo "<data store>: $DATA_STORE" >> $LOGFILE
echo "<file>: $FILE" >> $LOGFILE


# イメージファイルのみを処理対象にする
if [ "x$IMAGEFILE" != "x" -a $IMAGEFILE != `basename $FILE` ]
then
    echo "File($FILE) is not target($IMAGEFILE)." >> $LOGFILE
    exit 0
fi

# ファイルパス(URL)
FILE_PATH=${FILE#${DATA_STORE}}

echo "FILE_PATH: $FILE_PATH" >> $LOGFILE

# 装置ID
MONITOR_ID=`echo $FILE_PATH | cut -d "/" -f 4`

echo "MONITOR_ID: $MONITOR_ID" >> $LOGFILE

# 比較対象ファイル特定
NOW=$FILE
PREV=`ls ${DATA_STORE}/ペット見守り/MONITOR/${MONITOR_ID}/????/??/??/??????/picture.jpeg | sort | grep -B 1 $NOW | grep -v $NOW`
if [ "x$PREV" = "x" ]
then
    PREV="NONE"
fi

echo $PREV - $NOW >> $LOGFILE

# 差分抽出
echo "call $PG $PREV $NOW ${TMP_DIR}/$PREFIX" >> $LOGFILE
$PG $PREV $NOW ${TMP_DIR}/$PREFIX >> $LOGFILE
RET=$?

echo "-> $RET" >> $LOGFILE

if [ $RET -ne 0 ]
then
    echo "エラー、または、差分あり : 差分があれば情報を保存" >> $LOGFILE

    # 抽出情報を保存
    BASE_PATH=`dirname $FILE_PATH`
    echo "BASE_PATH: \"$BASE_PATH\"" >> $LOGFILE
    for file in `ls $TMP_DIR`
    do
	echo send $file >> $LOGFILE
	$CURL -F "name=${BASE_PATH}/${file}" -F "file=@$TMP_DIR/$file" "$STORAGE_SERVER"
    done
else
    echo "差分なし : ファイルを削除" >> $LOGFILE
    echo "call $CURL -v -X DELETE \"${STORAGE_SERVER}${FILE_PATH}\""  >> $LOGFILE
    $CURL -v -X DELETE ${STORAGE_SERVER}${FILE_PATH}
    RET=$?
    echo "-> $RET" >> $LOGFILE
fi

# ファイル一覧を記録
find $TMP_DIR >> $LOGFILE

# 作業ディレクトリを削除
rm -rf $TMP_DIR

echo "END: `date`" >> $LOGFILE
