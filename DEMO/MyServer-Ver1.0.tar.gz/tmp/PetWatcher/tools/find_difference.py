#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
今はエラー処理などは省略している!!!
"""

import cv2
import numpy 
import sys
import json
import os

# 差分を取得
def get_difference(img, prev):

    # 背景差分を使って画像の変化を検出
    fgbg = cv2.bgsegm.createBackgroundSubtractorMOG()
    fgmask = fgbg.apply(prev)
    fgmask = fgbg.apply(img)

    # ノイズ除去
    diff_image = cv2.medianBlur(fgmask, 7)
    
    return diff_image


# 変化のあった領域を取得。全体
def get_area(image):
    # numpy.maxでimgの最大値を取得する。0の場合は差分がない。
    if numpy.max(image) > 0:
        diff_x, diff_y = numpy.where(image > 1)
        x_min = numpy.min(diff_x)
        y_min = numpy.min(diff_y)
        x_max = numpy.max(diff_x)
        y_max = numpy.max(diff_y)
        print x_min, y_min, x_max, y_max

        if x_min == x_max or y_min == y_max:
            print("NOT Found Difference")
            return None
        else:
            print("Found Difference")
            return [(x_min, y_min),(x_max, y_max)]

    else:
        print("NOT Found Difference")
        return None


# 差異のあった位置情報ををJSON形式で書き出す
def save_difference_area(file_name, area):
    x_min, y_min = area[0]
    x_max, y_max = area[1]
    info = {"area":{"X":[x_min, x_max], "Y":[y_min, y_max]}}
    f = open(file_name,'w')
    json.dump(info, f)



# 差異部分を切り出した画像を保存する
def save_difference_image(file_name, image, area):
    x_min, y_min = area[0]
    x_max, y_max = area[1]
    #               上　　下     左    右
    img = image[x_min:x_max,y_min:y_max]
    cv2.imwrite(file_name, img)


# メイン処理
if __name__ == '__main__':

    if len(sys.argv) < 3:
        print('Usage: find_difference.py <prev> <image> <prefix>')
        sys.exit(99)

    print "Processing"

    # 引数の取得
    prev_file = sys.argv[1]
    image_file = sys.argv[2]
    prefix = sys.argv[3]

    if prev_file == "NONE":
        print('There is NO previous Image.')
        sys.exit(1)

    print(prev_file)
    print(image_file)
    print(prefix)


    # 画像の読み込み
    prev_img = cv2.imread(prev_file, 1)
    now_img = cv2.imread(image_file, 1)

    # 差分検出
    diff_img = get_difference(now_img, prev_img)
    print(diff_img)

    # 差分領域取得
    area = get_area(diff_img)
    print(area)

    if area != None:
        x_min, y_min = area[0]
        x_max, y_max = area[1]
        print(x_min, y_min, x_max, y_max)

        # 領域情報を生成
        save_difference_area(prefix+"_area.json", area)

        # 画像を切り抜いて保存
        save_difference_image(prefix+"_prev_diff.jpeg", prev_img, area)
        save_difference_image(prefix+"_diff.jpeg", now_img, area)

        sys.exit(1)
    else:
        sys.exit(0)
