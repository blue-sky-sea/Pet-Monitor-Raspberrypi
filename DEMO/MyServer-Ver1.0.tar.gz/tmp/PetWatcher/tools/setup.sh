#!/bin/bash

MYSERVER_TOP=$1
TOOLS_TOP=$2

if [ "x$MYSERVER_TOP" = "x" ]
then
    exit 1
fi

if [ "x$TOOLS_TOP" = "x" ]
then
    exit 1
fi

