#!/bin/bash

MYSERVER_TOP=$1
MONITOR_TOP=$2

if [ "x$MYSERVER_TOP" = "x" ]
then
    exit 1
fi

if [ "x$MONITOR_TOP" = "x" ]
then
    exit 1
fi

mkdir -p $MONITOR_TOP/work


sudo apt-get install -y python-smbus
sudo pip install paho-mqtt
wget https://bootstrap.pypa.io/get-pip.py
sudo python3 get-pip.py
pip3.7 install slackclient
rm -f get-pip.py
