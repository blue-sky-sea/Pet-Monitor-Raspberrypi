#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
import sys
import os
import traceback
import picamera
import MyServer.mystorage as MyStorage
import MyServer.common as MyCom
import datetime
import shutil

#debug_mode = True
debug_mode = False

# config.jsonを読み、パラメータを取得
MyCom.load_config('./config.json')
my_id = MyCom.id()
storage_service = MyCom.storage()
interval = MyCom.interval()
app_id = MyCom.app_id()
pic_size = MyCom.pic_size()


# カメラ初期化
camera = picamera.PiCamera()

# サイズなどの設定
camera.saturation = 0
#camera.saturation = -100
#camera.resolution = (3280, 2464)
#camera.resolution = (1920, 1080)
camera.resolution = (pic_size[0], pic_size[1])

# ストレージ・サービスのURLを設定
MyStorage.set_url(storage_service)

# ファイル保存先
save_folder = "./SAVE/"

# 撮影、データ送信を無限ループ
while True:
    try:
        # 画像撮影
        pic = os.path.join(MyCom.work_dir(), 'image.jpg')
        if debug_mode:
            print(sys._getframe().f_code.co_name+':pic='+pic)

        camera.capture(pic)

        # ファイル名を組み立てる(デフォルト)
        #path = MyCom.monitor_picture_path()
        dt_now = datetime.datetime.now()
        path = save_folder + dt_now.strftime('%Y%m%d%H%M%S') + "picture.jpeg"
        if debug_mode:
            print(sys._getframe().f_code.co_name+':path='+path)

        # 画像保存
        #res = MyStorage.save_file(path, pic)
        #if res != 200:
        #    print('Failed to save file.')
        shutil.copy(pic, path)

    except KeyboardInterrupt:
        break
    except:
        print(traceback.format_exc())
        pass


    # 指定時間待ち
    if debug_mode:
        print('sleep: %d' % (interval))
    time.sleep(interval)

