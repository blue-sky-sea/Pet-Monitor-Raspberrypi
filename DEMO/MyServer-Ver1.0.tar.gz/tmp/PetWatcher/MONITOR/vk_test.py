#!/usr/bin/env python
# -*- coding: utf-8 -*-

import VisionKit.visionkit as visionkit
import json

'''
vk_config.json
{
        "SSH_IP":"127.0.0.1",
        "SSH_PORT":22222,
        "SSH_USER":"pi",
        "SSH_PASSWD":"raspberry"
}
'''

f = open('./vk_config.json', 'r')
vk_conf = json.load(f)
f.close()
print(vk_conf)



#vk = visionkit.VK('192.168.2.8', 22, 'pi', 'raspberry')
#vk = visionkit.VK('127.0.0.1', 22222, 'pi', 'raspberry')
vk = visionkit.VK(vk_conf['SSH_IP'], vk_conf['SSH_PORT'], vk_conf['SSH_USER'], vk_conf['SSH_PASSWD'])
print(vars(vk))

res = vk.vk_is_cat('test_pic/cat.jpg', 'test_res/cat_result.jpg')
print(res)
res = vk.vk_is_cat('test_pic/cats.jpg', 'test_res/cats_result.jpg')
print(res)
res = vk.vk_is_cat('test_pic/cat2.jpg', 'test_res/cat2_result.jpg')
print(res)
res = vk.vk_is_cat('test_pic/human.jpg', 'test_res/human_result.jpg')
print(res)
res = vk.vk_is_cat('test_pic/dog.jpg', 'test_res/dog_result.jpg')
print(res)
res = vk.vk_is_cat('test_pic/city.jpg', 'test_res/city_result.jpg')
print(res)

