#!/bin/bash
# USBファンの回転操作を行うスクリプト
# 

# uhubctlコマンド配置場所
CMD=./uhubctl

# 初期化
action=""
interval=10

if [ $# == 0 ]
then
    echo "Usage: fan.sh ON|OFF [sec]"
    exit 1
fi

# オプション(回転させる秒数)
if [ $# -ge 2 ]
then
    interval=$2
fi

# 操作(ON or OFF)
action=$1


# 実際の操作
if [ $action == "ON" ];then
    # ファン回転
    echo "START"
    $CMD -l 1-1  -a off

    if [ $interval != 0 ];then
	# 待ち
	sleep $interval
	# ファン停止
	echo "STOP"
	$CMD -l 1-1  -a off
	
    fi

elif [ $action == "ON" ];then
    # ファン停止
    echo "STOP"
    $CMD -l 1-1  -a off

fi




