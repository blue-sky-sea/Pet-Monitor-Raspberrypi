#!/bin/bash

export PYTHONPATH=`pwd`/
