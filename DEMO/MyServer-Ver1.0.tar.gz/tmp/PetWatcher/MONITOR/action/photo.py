#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
import sys
import os
import traceback
import picamera
import MyServer.mystorage as MyStorage
import MyServer.common as MyCom


debug_mode = True
#debug_mode = False

# config.jsonを読み、パラメータを取得
MyCom.load_config('./config.json')
my_id = MyCom.id()
storage_service = MyCom.storage()
interval = MyCom.interval()
app_id = MyCom.app_id()
pic_size = MyCom.pic_size()

# 引数解析
opt = None
if len(sys.argv) > 1:
    opt = unicode(sys.argv[1], 'utf-8')
    if debug_mode:
        print("opt = " + opt)


# カメラ初期化
camera = picamera.PiCamera()

# サイズなどの設定
camera.saturation = 0
camera.resolution = (pic_size[0], pic_size[1])

# ストレージ・サービスのURLを設定
MyStorage.set_url(storage_service)

# 撮影、データ送信
try:
    # 画像撮影
    pic = os.path.join("./", 'photo.jpg')
    if debug_mode:
        print(sys._getframe().f_code.co_name+':pic='+pic)

    camera.capture(pic)

    # ファイル名を組み立てる(デフォルト)
    if opt != None:
        path = os.path.join(app_id, 'MONITOR', my_id, opt)
    else:
        path = os.path.join(app_id, 'MONITOR', my_id, u'近づいたもの', 'photo.jpg')

    if debug_mode:
        print(sys._getframe().f_code.co_name+':path='+path)

    # 画像保存
    res = MyStorage.save_file(path, pic)
    if res != 200:
        print('Failed to save file.')

except:
    print(traceback.format_exc())
    pass

