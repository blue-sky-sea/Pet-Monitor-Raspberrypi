#!/bin/bash
#

OPT=$1

echo "シャャー"
echo $OPT
