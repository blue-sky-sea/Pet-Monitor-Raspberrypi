#!/bin/bash

echo $#
if [ $# -lt 1 ];then
	echo "Usage:light <ON|OFF|second>"
	exit 1
fi

OPT=$1

if [ $OPT = "ON" ];then
    echo "turn on the light"
elif [ $OPT = "OFF" ];then
    echo "turn off the light"
else
    echo "INVALID ACTION : $OPT"
fi

