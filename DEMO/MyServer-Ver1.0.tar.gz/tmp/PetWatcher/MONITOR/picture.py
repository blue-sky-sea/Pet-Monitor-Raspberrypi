#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
import sys
import os
import json
import traceback
import picamera
import MyServer.mystorage as MyStorage
import MyServer.common as MyCom
import VisionKit.visionkit as visionkit
'''
MyserverおよびVisionKiライブラリをロードするために以下の環境変数設定が必要
export PYTHONPATH=$HOME/CQ/MyServer/LIB/python/:$HOME/CQ/MyServer/AI/:$PYTHONPATH
'''

debug_mode = True
#debug_mode = False

# config.jsonを読み、パラメータを取得
MyCom.load_config('./config.json')
my_id = MyCom.id()
storage_service = MyCom.storage()
interval = MyCom.interval()
app_id = MyCom.app_id()
pic_size = MyCom.pic_size()
cat_only = MyCom.cat_only()

# カメラ初期化
camera = picamera.PiCamera()

# サイズなどの設定
camera.saturation = 0
#camera.saturation = -100
#camera.resolution = (3280, 2464)
#camera.resolution = (1920, 1080)
camera.resolution = (pic_size[0], pic_size[1])

# ストレージ・サービスのURLを設定
MyStorage.set_url(storage_service)

# Vision Kitを使った画像認識実行の準備
f = open('./vk_config.json', 'r')
vk_conf = json.load(f)
f.close()
if debug_mode:
    print(vk_conf)

vk = visionkit.VK(vk_conf['SSH_IP'], vk_conf['SSH_PORT'], vk_conf['SSH_USER'], vk_conf['SSH_PASSWD'])
print(vars(vk))

# 撮影、データ送信を無限ループ
while True:
    try:
        # 画像撮影
        pic = os.path.join(MyCom.work_dir(), 'image.jpg')
        if debug_mode:
            print(sys._getframe().f_code.co_name+':pic='+pic)

        camera.capture(pic)

        # 猫が写っているか判断する
        if cat_only == False or cat_only and vk.vk_is_cat(pic, None):
            # ファイル名を組み立てる(デフォルト)
            path = MyCom.monitor_picture_path()
            if debug_mode:
                print(sys._getframe().f_code.co_name+':path='+path)

            # 画像保存
            res = MyStorage.save_file(path, pic)
            if res != 200:
                print('Failed to save file.')

        # 指定時間待ち
        if debug_mode:
            print('sleep: %d' % (interval))
        time.sleep(interval)

    except:
        print(traceback.format_exc())
        break



