#!/usr/bin/env python
# -*- coding: utf-8 -*-

from smbus import SMBus
import time

import bme280_sample as BME280

def get_data():
	t,p,h = BME280.readData()
	d = BME280.makeJSON(t,p,h)
	return d

