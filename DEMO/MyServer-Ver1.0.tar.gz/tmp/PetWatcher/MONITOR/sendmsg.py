#!/usr/bin/python3
# -*- coding: utf-8 -*-

import slack
import os
slack_token='xoxb-912849079590-908958063427-gpi4m3olBASh2s2wk6nUzZAW'
client = slack.WebClient(token=slack_token)
client.chat_postMessage(channel="myserver",text="Hello from PetWatcher app!")
