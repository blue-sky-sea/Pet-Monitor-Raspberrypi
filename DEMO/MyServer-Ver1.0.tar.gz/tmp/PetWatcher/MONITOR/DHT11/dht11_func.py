#!/usr/bin/env python
# -*- coding: utf-8 -*-

import RPi.GPIO as GPIO
import DHT11_Python.dht11 as DHT11
import time
import json

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.cleanup()

instance = DHT11.DHT11(pin=14)

def get_data():
    result = instance.read()
    if result.is_valid():
        dp = {"temperature":result.temperature, "humidity":result.humidity}
    else:
        dp = {}

    d = json.JSONEncoder().encode(dp)

    return d


if __name__ == '__main__':
    while True:
        res = get_data()
        print(res)

        time.sleep(1)
