#!/usr/bin/python3
# -*- coding: utf-8 -*-

import time
import sys
import os
import traceback
import json
import subprocess
import slack

# デバッグモード
#debug_mode=True
debug_mode=False


# slackへのメッセージ送信
def send_message(token, channel, distance):
    if debug_mode:
        print("send_message:" + token + "," + channel)

    txt = "何かが接近しています。距離 " + str(distance) + " cm"

    client = slack.WebClient(token=token)
    client.chat_postMessage(channel=channel, text=txt)

    if debug_mode:
        print(txt)

    msg = {"STATUS":"OK", "INFO":""}

    return msg


# メッセージに応じたアクションの実行
def do_action(act, id, distance):
    if debug_mode:
        print("do_action")
    msg = None
    info =""
    for target,opt in act.items():
        if debug_mode:
            print(target + ":" + opt)
        if target == "MESSAGE":
            if debug_mode:
                print("MESSAGE")
            o = opt.split(",")
            msg = send_message(o[0], o[1], distance)
        else:
            if debug_mode:
                print(target)
    	    # アクション実行指示作成
            msg = {"ID":id,"TYPE":"ACTION", "TARGET":target, "OPTION":opt}


    if msg == None:
        # 完了メッセージ
        msg = {"STATUS":"OK", "INFO":info}

    return msg



# 設定ファイルを読み込んで、判定の準備
'''
環境変数MYSERVER_AUTOMATE_CONFIG_PATHで設定ファイルの配置場所を設定しないとならない。
export MYSERVER_AUTOMATE_CONFIG_PATH=`pwd`/
'''
config_path = "./"
try:
    config_path = os.environ['MYSERVER_AUTOMATE_CONFIG_PATH']
except:
    print("No MYSERVER_AUTOMATE_CONFIG_PATH variable")

config_file = os.path.join(config_path, "distance_check.config")
if debug_mode:
    print("config file:" + config_file)

f = open(config_file, 'r')
conf = json.load(f)
f.close()
mon_id = conf['ID']
mqtt_broker = conf['MQTT']
mqtt_broker_addr = mqtt_broker.split(':')[0]
mqtt_broker_port = int(mqtt_broker.split(':')[1])
topic_pub = conf['TOPIC']
critical_lv = conf['DISTANCE'][0]
warning_lv = conf['DISTANCE'][1]
normal_lv = conf['DISTANCE'][2]
critical_act = {}
warning_act = {}
normal_act = {}
for act in conf['CRITICAL']:
    critical_act[act['TARGET']] = act['OPTION']

for act in conf['WARNING']:
    warning_act[act['TARGET']] = act['OPTION']

for act in conf['NORMAL']:
    normal_act[act['TARGET']] = act['OPTION']

if debug_mode:     
    print(conf)
    print(mon_id)
    print(critical_lv, warning_lv, normal_lv)
    print('critical_act:')
    print(critical_act)
    print('warning_act:')
    print(warning_act)
    print('normal_act:')
    print(normal_act)


# 標準入力からJSONデータを読み込む
df = json.load(sys.stdin)
if debug_mode:
    print(df)
msg_id = df['ID']
msg_type = df['TYPE']
distance = df['DISTANCE']


if mon_id != msg_id:
    ret = {"STATUS":"OK", "INFO":"Not My ID:" + str(msg_id)}
    json.dump(ret, sys.stdout)
    os.exit(0)

if msg_type != "DISTANCE":
    ret = {"STATUS":"OK", "INFO":"Not My Type:" + str(msg_type)}
    json.dump(ret, sys.stdout)
    os.exit(0)

if debug_mode:
    print(distance)

target = ""
opt = ""
# 閾値チェックおよびアクション実行
if distance < critical_lv:
    msg = do_action(critical_act, mon_id, distance)
elif distance < warning_lv:
    msg = do_action(warning_act, mon_id, distance)
elif distance > normal_lv:
    msg = do_action(normal_act, mon_id, distance)


# 標準出力にJSONデータを書き込む
json.dump(msg, sys.stdout)
