#!/bin/bash

MYSERVER_TOP=$1
AUTOMATE_TOP=$2

if [ "x$MYSERVER_TOP" = "x" ]
then
    exit 1
fi

if [ "x$AUTOMATE_TOP" = "x" ]
then
    exit 1
fi
