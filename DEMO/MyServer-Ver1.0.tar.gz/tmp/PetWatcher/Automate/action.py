#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import json
import subprocess


'''

Automateで呼び出されるアクション

ここから、各種アクションを実行するコマンドを呼び出す

出力は、以下のJSON形式。
{
	"STATUS":"OK",
        "INFO":""
}

'''


def do_cmd(cmd, action ,opt):
    print(cmd,action,opt)
    ret = subprocess.call([cmd, action, opt])
    print(ret)
    return ret


# ここから処理本体
# 設定ファイル(action_config.json)を読み込む
f = open('./action.config', 'r')
config = json.load(f)
f.close()

print(config)

my_id = config['ID']

# コマンドの配置パスを取得
cmd_base = config['ACTION_BASE']

# TARGETと実行コマンドの組を辞書に入れる
cmd_list = {}
for rec in config['ACTION']:
    print(rec)
    cmd_list[rec['TARGET']] = rec['COMMAND']

print(cmd_list)


# 標準入力からJSONデータを読み込む
df = json.load(sys.stdin)

# メッセージ解析
monitor_id = df['ID']
type = df['TYPE']
target = df['TARGET']
action = df['ACTION']
opt = df['OPTION']


# 自分へのリクエストでなければ何もしない
if monitor_id != my_id:
    print("Not mine.")
    ret = {"STATUS":"OK", "INFO":"Not Mine."}
    json.dump(ret, sys.stdout)



# コマンド実行
cmd = cmd_list[target]
rc = do_cmd(os.path.join(cmd_base,cmd), action, opt)

if rc == 0:
    status = "OK"
    info =""
else:
    status = "NG"
    info ="Failed to execute " + cmd



# 実行結果をJSONメッセージにして標準出力に書き込む
ret = {"STATUS":status, "INFO":info}
json.dump(ret, sys.stdout)


'''
本当は、結果を返さないコマンドも実行できるようにしたい。
その場合、MyIOTサービスのAutomateのexecutorなどの修正が必要となる。

'''

