/*

PetWatcher APIを呼び出すスクリプト


装置一覧をリストで返す

*/


//var petwatcher_url = "http://127.0.0.1:8080";
var petwatcher_url = "";



// モニタ装置IDを一覧で取得する。IDでソートする。
function myapp_get_monitor_list(cb) {
    let req = new XMLHttpRequest();
    req.onreadystatechange = function(){
	if (this.readyState == 4 && this.status == 200) {
	    let ml = JSON.parse(this.response, 'utf8');
	    cb(ml.list.sort());
	}
    }
    req.open('GET', petwatcher_url + '/monitor/');
    req.send();
}

// モニタ装置の詳細情報を取得する。
function myapp_get_monitor_info(mon_id, cb) {
    let req = new XMLHttpRequest();
    req.onreadystatechange = function(){
	if (this.readyState == 4 && this.status == 200) {
	    let body = JSON.parse(this.response);
	    cb(body.info);
	}
    }
    req.open('GET', petwatcher_url + '/monitor/' + mon_id);
    req.send();


}


// 装置IDと日時で指定した画像を取得する
function myapp_get_picture(mon_id, from, to, cb) {

    /*
	画像を取り出す。結果はコールバックで受け渡す。
	ファイルを時間範囲指定で検索
	http://localhost:8080/sensor/RASPI_MON2/target/?from=20190923111111&to=20190924222222

	存在すれば画像を取り出して返す。
	存在しない場合はnullを返す。
	複数ある場合は、最新のものを返す。
    */

    let _get_image = function(file) {
	let req = new XMLHttpRequest();
	req.onreadystatechange = function(){
	    if (this.readyState == 4 && this.status == 200) {
		data = this.response;
		let reader = new FileReader();
		reader.onloadend = function() {
		    cb(reader.result);
		}
		reader.readAsDataURL(data);
	    }
	}
	req.open('GET', petwatcher_url + '/picture/' + mon_id + '/' + file);
	req.responseType = 'blob';
	req.send();
    }


    let req = new XMLHttpRequest();
    req.onreadystatechange = function(){
	if (this.readyState == 4 && this.status == 200) {
	    let ml = JSON.parse(this.response, 'utf8');
	    console.log(mon_id,":file list->", ml);

	    let f = ml.list.sort().slice(-1)[0];
	    console.log(f);
	    if (f) {
		_get_image(f);
	    }
	    else {
		cb(null);
	    }
	}
    }
    req.open('GET', petwatcher_url + '/picture/' + mon_id + '/?from=' + from + '&to=' + to);
    req.send();


}


// 装置IDと日時で指定したセンサデータを取得する
function myapp_get_sensor(mon_id, from, to, interval, cb) {

    /*
	センサーデータを取り出す。結果はコールバックで受け渡す。
	ファイルを時間範囲指定で検索
	http://localhost:8080/sensor/RASPI_MON2/target/?from=20190923111111&to=20190924222222

	存在すれば取り出して返す。
	存在しない場合は空のリストを返す。
	複数ある場合は、全部を配列で返す。
	[{"time":"日時" , "data": センサーデータ},...]
	

    */

    let _get_data = function(i, file, f) {
	let req = new XMLHttpRequest();
	req.onreadystatechange = function(){
	    if (this.readyState == 4 && this.status == 200) {
		f(JSON.parse(this.response, 'utf8'));
	    }
	}
	req.open('GET', petwatcher_url + '/sensor/' + mon_id + '/' + file);
	req.send();
    }


    let req = new XMLHttpRequest();
    req.onreadystatechange = function(){
	if (this.readyState == 4 && this.status == 200) {
	    let ml = JSON.parse(this.response, 'utf8');
	    console.log(mon_id,":file list->", ml);
	    let result_list = [];
	    let f = ml.list.sort();
	    console.log(f);
	    let cnt = f.length;
	    if (cnt) {
		for(let i in f) {
		    _get_data(i, f[i], function(r) {
			    result_list[i] = {"time": f[i], "data": r};
			    cnt--;
			    if (cnt == 0){
				console.log("done", result_list);
				cb(result_list);
			    }
			});
	    	}
	    }
	    else {
		cb(result_list);
	    }
	}
    }
    req.open('GET', petwatcher_url + '/sensor/' + mon_id + '/?from=' + from + '&to=' + to);
    req.send();


}



// 表示サイズを取得する

// 更新間隔を取得する

// 日付を取得する

// 時刻を取得する


