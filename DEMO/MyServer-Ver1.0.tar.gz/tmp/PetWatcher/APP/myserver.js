var http = require('http');
var fs = require('fs');
var path = require('path');
var async = require('async');
var request = require('request');
var storage_url = "http://127.0.0.1:4001";

// 初期化
function init(url) {
    console.log(url);
    if (url != null) {
	storage_url = "http://" + url + "/storage/";
    }
}


// ファイルをストーレジサービスに保存する
function upload_file(file_name, file_data, cb) {
    // 保存ファイルの設定
    let form = {
	"file": fs.createReadStream(file_data),
	"name": file_name
    }
    // POSTで保存
    request.post({url: storage_url, formData: form}, cb);
    return;
}


function build_url(name) {
    let url = storage_url;
    if (name) {
	if (name[0] == '/') {
	    url = url + encodeURIComponent(name.substr(1, name.length));
	}
	else {
	    url = url + encodeURIComponent(name);
	}
    }
    return url;
}

// ファイル一覧を取得する
function list_files(base, cb) {
    // GETでリスト取得
    let url = build_url(base);
    console.log("list_files:", url)
    request.get(url+"?format=json", function(error, response, body){
	    // JSONをパースし、コールバックで結果を返す
	    console.log(error);
	    if (error == null) {
		if (JSON.parse(body)) {
		    cb(JSON.parse(body).files);
		}
		else {
		    cb([]);
		}
	    }
	    else {
		cb(['Storage Server is not working.']);
	    }
    });
}

// ファイルを取得する
function get_file(name, encode, cb) {
    // GETでファイルを取得
    let url = build_url(name);
    console.log("get_file:", url)
    request.get(url, encode, function(error, response, body){
	    // bodyがファイルのコンテンツなので、結果として返す。
	    console.log(error);
	    if (error == null) {
		cb(body);
	    }
	    else {
		cb('Storage Server is not working.');
	    }
    });

}

module.exports = {
	init,
	upload_file,
	list_files,
	get_file,
};
