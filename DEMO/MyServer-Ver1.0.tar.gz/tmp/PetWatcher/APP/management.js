/*
モニタ装置管理関連

管理情報をファイルで管理するバージョン
*/

// 必要モジュールのロード
var fs = require('fs');
var path = require('path');
var async = require('async');



function read_json(file) {
    let info = JSON.parse(fs.readFileSync(file, 'utf8'));
    console.log(info);
    return info;
}


// システム情報を参照
function get_sys_info() {
    // 情報を取り出す
    let info_f = path.join(global.INFO_DIR, 'info');
    console.log(info_f);

    // 結果をJSON形式で返す
    return read_json(info_f);
}


// モニタ装置一覧を取得
function get_monitor_list() {
    let mon_list = [];

    // ファイル一覧がモニタ装置の一覧
    // モニタ装置情報が配置されているディレクトリ配下のファイル一覧を作成する。これが装置一覧。
    let dir = path.join(global.INFO_DIR, 'MONITOR');
    console.log(dir);

    files = fs.readdirSync(dir);
    for(let f of files) {
	console.log(f);
	mon_list.push(f);
    }
    console.log(mon_list);

    // 結果を返す
    return mon_list;
}


// モニタ装置の詳細を取得
function get_monitor_info(monitor_id) {
    // 情報を取り出す
    let info_f = path.join(global.INFO_DIR, 'MONITOR', monitor_id);
    console.log(info_f);

    // 結果をJSON形式で返す
    return read_json(info_f);

}


module.exports = {
    get_sys_info,
    get_monitor_list,
    get_monitor_info
};
