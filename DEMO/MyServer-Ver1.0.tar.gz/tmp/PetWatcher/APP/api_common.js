var http = require('http');
var fs = require('fs');
var path = require('path');
var async = require('async');
var request = require('request');

var storage_url = "http://127.0.0.1:4001";


// MyServerアクセスモジュールのロード
var storage = require('./myserver');


/*
パラメータ取得
from,toパラメータを取り出す。

パラメータは以下の形式で渡される。
[picture|sensor]/<モニタ装置ID>/?from=XXXX&to=YYYYYY 

結果は配列で返す。0の場合していなし。
[0,0]  => オプション指定なし。
[0, Y] => from指定はなし
[X, 0] => to指定はなし
*/

function check_valid_value(val) {

    if (val.length != 14) {
	console.log("invalid length")
	return false;
    }
    
    if (isNaN(val)) {
	console.log("invalid value")
	return false;
    }
    return true;
}

function get_range(req) {
    let range = ['0','21001231235959'];

    console.log(req.query);

    // from
    if (req.query.from) {
	if (check_valid_value(req.query.from)) {
	    range[0] = req.query.from;
	}
    }

    // to
    if (req.query.to) {
	if (check_valid_value(req.query.to)) {
	    range[1] = req.query.to;
	}
    }

    console.log(range);

    return range
}

/*
指定時間のファイル一覧を取得
指定範囲に存在するデータを見つける

結果は、ストレージサービスのパス名のリストで返す。

*/
function get_target_list(monitor_id, file_name, from, to, cb) {
    console.log("get_target_list");

    let file_list = [];

    // URL組み立て
    let base_dir = path.join(global.APP_NAME, 'MONITOR', monitor_id);

    /*
      fromとtoの
      年月日が同じなら、年月日まで指定してファイル検索(mode=3)
      年月が同じなら、年月まで指定してファイル検索(mode=2)
      年が同じなら、年まで指定してファイル検索(mode=1)
      異なる場合、モニタ装置IDのみ指定して検索(mode=0)
    */
    let mode = 0;
    let year_f = from.substr(0,4);
    let month_f = from.substr(4,2);
    let day_f = from.substr(6,2);
    let year_t = to.substr(0,4);
    let month_t = to.substr(4,2);
    let day_t = to.substr(6,2);

    path_head = "/";
    if (year_f == year_t) {
	base_dir = path.join(base_dir, year_f);
	mode += 1;
	path_head = path.join(path_head, year_f);
    }
    if (month_f == month_t) {
	base_dir = path.join(base_dir, month_f);
	mode += 1;
	path_head = path.join(path_head, month_f);
    }
    if (day_f == day_t) {
	base_dir = path.join(base_dir, day_f);
	mode += 1;
	path_head = path.join(path_head, day_f);
    }

    console.log("get_target_list: base_dir = ", base_dir)

    // ストレージサービスから一覧を取得する
    storage.list_files(base_dir + '/', function(list){
	    console.log(list);
	    // ファイル名と日時範囲のチェック
	    for(let f of list) {
		console.log(f);
		f = path.join(path_head, f);
		let com = f.split('/');
		console.log(com);
		let t = com[1] + com[2] + com[3] + com[4];
		console.log(t);

		if (com[5] == file_name && Number(from) <=  Number(t) && Number(t) <= Number(to)) {
			file_list.push(t);
		}
	    }

	    cb(file_list);
	});

}

// 指定時間に一番近い過去のもの
function get_target(monitor_id, file_name, to, cb) {
    console.log("get_targett");

    let file = 0;

    let base_dir = path.join(global.APP_NAME, 'MONITOR', monitor_id);

    /*
      年月日の中で探すので、日が変わった場合はみつからない。

      年月日も指定して検索(mode=3)
      なければ、年月も指定して検索(mode=2)
      なければ、年も指定して検索(mode=1)
      なければ、モニタ装置IDだけ指定して(mode=0)
    */
    let mode = 0;
    let year = to.substr(0,4);
    let month = to.substr(4,2);
    let day = to.substr(6,2);

    path_head = "/";
    base_dir = path.join(base_dir, year);
    mode += 1;
    path_head = path.join(path_head, year);
    base_dir = path.join(base_dir, month);
    mode += 1;
    path_head = path.join(path_head, month);
    base_dir = path.join(base_dir, day);
    mode += 1;
    path_head = path.join(path_head, day);

    console.log("get_target_list: base_dir = ", base_dir)

    // ストレージサービスから一覧を取得する
    storage.list_files(base_dir + '/', function(list){
	    console.log(list);

	    // ファイル名と日時範囲のチェック
	    for(let f of list) {
		console.log(f);
		f = path.join(path_head, f);
		let com = f.split('/');
		console.log(com);
		let t = com[1] + com[2] + com[3] + com[4];
		console.log(t);

		if (com[5] == file_name && Number(t) <= Number(to) && Number(file) < Number(t)) {
		    file = t;
		}
	    }

	    cb(file);
	});

}


// モニタ装置ID，日時，ファイル名を指定してファイルを取り出す。
function get_file(req, name, encode, cb) {

    console.log(name, encode);

    let monitor_id = req.params.id;
    let datetime = req.params.datetime;

    if (datetime.length < 14) {
	cb(null);
	return;
    }

    let year = datetime.substr(0,4);
    let month = datetime.substr(4,2);
    let day = datetime.substr(6,2);
    let time = datetime.substr(8,6);

    console.log("get_file:", monitor_id, year, month, day, time, name);

    let file = path.join(global.APP_NAME, 'MONITOR', monitor_id, year, month, day, time, name);
    console.log(file);
    storage.get_file(file, encode, function(data){
	    console.log("get_file", data);
	    cb(data);
	});
}


// モジュール初期化関数
function init(config) {
    console.log("api_common.js:init");
    console.log(config);
    // ストレージ・サービスへのアクセス設定
    let storage_url = config.STORAGE_HOST + ":" + config.STORAGE_PORT;
    
    storage.init(storage_url);

}



module.exports = {
    init,
    get_range,
    get_target_list,
    get_target,
    get_file,
};
