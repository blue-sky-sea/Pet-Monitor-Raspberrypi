/* 
   PetWacher：ペット見守り

 */

// 必要モジュールのロード
var express = require('express');
var cors = require('cors');
var favicon = require('serve-favicon');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var async = require('async');
var fs = require('fs');
var path = require('path');
var request = require('request');
var multer = require('multer');

// API共通ジュールのロード
var common = require('./api_common');
var manager = require('./management');

// Expressアプリケーション作成
var app = express();

// 設定ファイル読み込み
var config = JSON.parse(fs.readFileSync(path.join(__dirname, 'CONFIG/config.json'), 'utf8'));
var port = config.PORT;
var app_name = config.APP_NAME;
var info_dir = config.INFO_DIR;
var storage_url = config.STORAGE_HOST + ":" + config.STORAGE_PORT;

// グローバル
global.BASEDIR = __dirname;
global.CONFIG = config;
global.APP_NAME = app_name;
global.INFO_DIR = info_dir;
global.STORAGE_URL = storage_url;


// CORS有効化
app.use(cors())

// favicon設定
app.use(favicon(path.join(__dirname, config.STATIC_FILE, 'favicon.ico')));

// リクエストBody
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Cookie対応
app.use(cookieParser());

// 静的ファイルの設定
app.use(express.static(path.join(__dirname, config.STATIC_FILE)));


// API初期化
common.init(config);


/*
  ルーティング設定
  /sensor/		センサーデータ
  /picture/		画像データの一覧画面
  			＊動画もここにするか？別にするか？
  /monitor/		モニタ装置の管理
*/
// システム情報を返却する
app.get('/info', function(req, res, next) {
	res.json(manager.get_sys_info());
    });

// センサーデータを参照するAPI処理
app.use('/sensor', require('./api_sensor'));
// 画像データを参照するAPI処理
app.use('/picture', require('./api_picture'));
// モニタ装置情報を参照するAPI処理
app.use('/monitor', require('./api_monitor'));

// サーバ起動
app.listen(port, function () {
	console.log(app_name + ' listening on port ' + port);
});


