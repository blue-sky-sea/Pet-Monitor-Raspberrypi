var express = require('express');
var router = express.Router();
var fs = require('fs');
var path = require('path');
var async = require('async');


// API共通ジュールのロード
var common = require('./api_common');
var manager = require('./management');


// 一覧取得
router.get('/', function (req, res, next) {
	console.log("Call ", req.method, req.path);

	// モニタ装置一覧を取得
	let list = manager.get_monitor_list();

	// レスポンスを組み立て
	let r = {status: 'success', number: list.length, list: list};
	res.json(r);
});


// 詳細情報取得
router.get('/:id/', function (req, res, next) {
	console.log("Call ", req.method, req.path);
	console.log(req.params.id);

	// モニタ装置IDを取得
	let monitor_id = req.params.id;

	// モニタ装置詳細情報を取得
	info = manager.get_monitor_info(monitor_id);

	// レスポンスを組み立て
	let r = {status: 'success', info: info};
	res.json(r);

});

module.exports = router;
