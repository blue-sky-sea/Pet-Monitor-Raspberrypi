var express = require('express');
var cors = require('cors');
var favicon = require('serve-favicon');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var async = require('async');
var fs = require('fs');
var path = require('path');
var request = require('request');
var multer = require('multer');
var storage = require('./mystorage');

// Expressアプリケーション作成
var app = express();

// 設定ファイル読み込み
var config = JSON.parse(fs.readFileSync(path.join(__dirname, 'CONFIG/config.json'), 'utf8'));
var port = config.PORT;
var file_dir = config.FILE_DIR;
var mystorage_folder = config.FOLDER

// テンプレート・エンジン設定
app.set('views', path.join(__dirname, 'view'));
app.set('view engine', 'pug');

// CORS有効化
app.use(cors())

// favicon設定
app.use(favicon(path.join(__dirname, './public/', 'favicon.ico')));

// リクエストBody
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Cookie対応
app.use(cookieParser());

// 静的ファイルの設定
app.use(express.static(path.join(__dirname, './public/')));


// Myストレージ・サービスの初期化
storage.init("http://" + config.STORAGE_HOST + ":" + config.STORAGE_PORT + "/storage/");

// ルーティング設定
app.get('/', function(req, res, next){
	// ファイル一覧を取得
	storage.list_files(function(list) {
		var my_list = [];
		if (list[0] == 'Storage Server is not working.') {
		    my_list.push('ERROR: Storage Server is NOT working.');
		}
		else {
		    // 自分のフォルダー配下のものだけに絞る
		    for (var file of list) {
			console.log(file);
			if (file.startsWith(mystorage_folder)) {
			    my_list.push(path.basename(file));
			}
		    }
		}
		// 画面表示
		res.render('main', { title: ' Myストレージ・サービス', storage_url: storage.get_url() + mystorage_folder, filelist: my_list });
	});
});

// アップロードファイルの保存先設定
var upload = multer({ dest: file_dir });

// アップロード処理
app.post('/upload', upload.single('file'), function(req, res, next){
	// ファイル名
	let file_name = req.file.originalname;
	let saved_file = path.join(file_dir, req.file.filename);

	console.log(file_name, saved_file);

	// アップロード
	var upload_file = path.join(mystorage_folder, file_name);
	storage.upload_file(upload_file, saved_file, function (error, response, body) {
	    console.log(error);
	    if (error) {
		var info = ": ERROR アップロード失敗";
	    }
	    else {
		var info = "アップロード完了";
	    }
	    // レスポンス
	    res.render('upload_result', { title: 'ファイルアップロード', file: file_name, info: info });
	})

});


// サーバ起動
console.log('STORAGE Service = ' + config.STORAGE_HOST + ":" + config.STORAGE_PORT);
app.listen(port, function () {
	console.log('File Viewer app listening on port ' + port);
});
