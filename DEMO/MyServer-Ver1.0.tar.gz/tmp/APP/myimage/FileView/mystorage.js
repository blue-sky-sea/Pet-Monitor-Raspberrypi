var http = require('http');
var fs = require('fs');
var path = require('path');
var async = require('async');
var request = require('request');
var storage_url = "http://127.0.0.1:4001";

// 初期化
function init(url) {
    console.log(url);
    if (url != null) {
	storage_url = url;
    }
}

// URLを取得
function get_url() {
    return storage_url;
}

// ファイルをストーレジサービスに保存する
function upload_file(file_name, file_data, cb) {
    // 保存ファイルの設定
    let form = {
	"file": fs.createReadStream(file_data),
	"name": file_name
    }
    // POSTで保存
    request.post({url: storage_url, formData: form}, cb);
    return;
}

// ファイル一覧を取得する
function list_files(cb) {
    // GETでリスト取得
    request.get(storage_url+"?format=json", function(error, response, body){
	    // JSONをパースし、コールバックで結果を返す
	    if (error == null) {
		if (JSON.parse(body)) {
		    cb(JSON.parse(body).files);
		}
		else {
		    cb([]);
		}
	    }
	    else {
		cb(['Storage Server is not working.']);
	    }
    });
}

module.exports = {
	init,
	get_url,
	upload_file,
	list_files,
};
