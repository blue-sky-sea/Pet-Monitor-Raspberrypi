#!/bin/bash

FILEVIEW_TOP=$1
if [ "x$FILEVIEW_TOP" = "x" ]
then
    exit 1
fi


pushd $FILEVIEW_TOP
npm install
popd

