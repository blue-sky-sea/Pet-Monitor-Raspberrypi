#!/bin/bash
TOOLS/SETUP/setup.sh
TOOLS/SETUP/genconfig.sh
. ./myserver.env
ln -sf TOOLS/SETUP/config/cmd ${MYSERVER_ROOT}/cmd

