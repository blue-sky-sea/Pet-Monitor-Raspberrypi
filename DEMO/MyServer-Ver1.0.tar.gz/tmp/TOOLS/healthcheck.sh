#!/bin/bash

DEBUG_MODE=1

. ../myserver.env


function do_get {
    name=$1
    target=$2
    while : ; do
       st=`curl $target -w '%{http_code}\n' -s -o /dev/null`
       if [ $st != "200" ];then
	   echo "  $name is DEAD !!!"
       elif [ $DEBUG_MODE = 1 ];then
	   echo "  $name is ALIVE"
       fi
       sleep 5
    done
}

function message {
    while : ; do
	echo '### press "return" to terminat health check.'
	sleep 10
    done
}

# CTL-Cを無効化
trap "" 2

pids=""

# Storage Service through LB
do_get "Storage Service(LB)" "$MYSERVER_STORAGE_SERVICE_URL" & 
pids="$pids $!"

# Storage Service
do_get "Storage Service" "$MYSERVER_STORAGE_SERVER_1_URL" &
pids="$pids $!"

# IoT Message Collector
do_get "IoT Message Collector" "$MYSERVER_IOT_COLLECTOR_URL" &
pids="$pids $!"

# IoT Message Distributor
do_get "IoT Message Distributor" "$MYSERVER_IOT_DISTRIBUTOR_URL" &
pids="$pids $!"

# IoT Automate
do_get "IoT Automate" "$MYSERVER_IOT_AUTOMATE_URL" &
pids="$pids $!"

message &
pids="$pids $!"

echo $pids

read -p "press "return" to terminat health check." ret

for pid in $pids
do
    echo $pid
    kill -9 $pid
done

sleep 2


