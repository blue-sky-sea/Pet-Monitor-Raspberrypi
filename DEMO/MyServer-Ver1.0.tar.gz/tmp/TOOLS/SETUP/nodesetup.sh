#!/bin/bash

MYSERVER_TOP=$1

if [ "x$MYSERVER_TOP" = "x" ]
then
    exit 1
fi


NODE_VER=v14.15.4

#ARC=linux-x64
ARC=linux-armv7l
#ARC=darwin-x64

FILE=node-${NODE_VER}-${ARC}.tar.xz
URL=https://nodejs.org/dist/${NODE_VER}/node-${NODE_VER}-${ARC}.tar.xz

if [ -f $MYSERVER_TOP/nodeenv.sh ]; then
    echo "Already installed Node.js."
    exit 0
fi

mkdir -p $MYSERVER_TOP/node

pushd $MYSERVER_TOP/download
wget  -nc -q $URL
popd

pushd $MYSERVER_TOP/node
tar Jxf $MYSERVER_TOP/download/${FILE}
popd


ENVFILE=$MYSERVER_TOP/nodeenv.sh
echo "export MYSERVER_NODE=$MYSERVER_TOP/node/node-${NODE_VER}-${ARC}" >> $ENVFILE
echo 'export PATH=$MYSERVER_NODE/bin:$PATH' >> $ENVFILE
