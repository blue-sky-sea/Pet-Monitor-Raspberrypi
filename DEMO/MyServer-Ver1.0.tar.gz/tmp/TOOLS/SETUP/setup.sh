#!/bin/bash

# 使うサーバ
# アカウント pi/raspberry
# MYSERVER_TOP

. TOOLS/SETUP/env
. TOOLS/SETUP/config/config
. TOOLS/SETUP/config/cmd

MYSERVER_TOP=`pwd`
echo $MYSERVER_TOP

mkdir -p $MYSERVER_TOP
mkdir -p $MYSERVER_TOP/download

echo "# env for Python script" > $MYSERVER_TOP/pythonenv.sh

# 必要パッケージインストール
echo "Installing required packages..."
TOOLS/SETUP/prerequirement.sh

# Go言語インストール
echo "Installing Go lang..."
TOOLS/SETUP/gosetup.sh $MYSERVER_TOP

source goenv.sh

# 必要なGoパッケージ
echo "Installing required Go packages..."
TOOLS/SETUP/go_package.sh

# Node.jsのインストール
echo "Installing Node..."
TOOLS/SETUP/nodesetup.sh $MYSERVER_TOP

source nodeenv.sh


# Storage Service
if [ "$USE_STORAGE" = "YES" ];then
    echo "Setting up Storage Service..."
    pushd $MYSERVER_TOP/$SRVTOP/Storage
    ./setup
    popd

    # Function
    echo "Setting up Function..."
    pushd $MYSERVER_TOP/$SRVTOP/Function
    ./setup
    popd

    # Event
    echo "Setting up Event..."
    pushd $MYSERVER_TOP/$SRVTOP/Event
    ./setup
    popd

fi

# IoT Service
if [ "$USE_IOT_COLLECTOR" = "YES" ] || [ "$USE_IOT_DISTRIBUTOR" = "YES" ] || [ "$USE_IOT_AUTOMATE" = "YES" ];then
    echo "Setting up IoT Service..."
    pushd $MYSERVER_TOP/$SRVTOP/IoT/
    ./setup
    popd
fi


# MQTT
if [ "$USE_MQTT" = "YES" ];then
    echo "Setting up MQTT Broker..."
    pushd $MYSERVER_TOP/$SRVTOP/IoT/MQTTBroker
    ./mqtt_setup.sh $MYSERVER_TOP
    popd
fi


# LB
if [ "$USE_LB" = "YES" ];then
    echo "Setting up Load Balancer..."
    pushd $MYSERVER_TOP/$LBTOP
    ./lbsetup.sh $MYSERVER_TOP
    popd
fi


# APP/FileView
if [ "$USE_FILEVIEW" = "YES" ];then
    echo "Setting up FileView..."
    pushd $MYSERVER_TOP/$APPTOP
    ./setup.sh $MYSERVER_TOP/$APPTOP/FileView
    popd
fi


# AI
echo "Setting up AI..."
pushd $MYSERVER_TOP/$AITOP
./setup.sh $MYSERVER_TOP $MYSERVER_TOP/$AITOP
popd

# PetWatcher
echo "Setting up PetWatcher..."
pushd $MYSERVER_TOP/$PETWATCHERTOP
## APP
echo "Setting up APP"
pushd APP
./setup.sh $MYSERVER_TOP $MYSERVER_TOP/$PETWATCHERTOP/APP
popd

## Automate
echo "Setting up Automate"
pushd Automate
./setup.sh $MYSERVER_TOP $MYSERVER_TOP/$PETWATCHERTOP/Automate
popd

## MONITOR
echo "Setting up MONITOR"
pushd MONITOR
./setup.sh $MYSERVER_TOP $MYSERVER_TOP/$PETWATCHERTOP/MONITOR
popd

## tools
echo "Setting up tools"
pushd APP
./setup.sh $MYSERVER_TOP $MYSERVER_TOP/$PETWATCHERTOP/tools
popd

popd

#


# LIB
echo "Setting up LIB..."
pushd $MYSERVER_TOP/$LIBTOP
./setup.sh $MYSERVER_TOP $MYSERVER_TOP/$LIBTOP
popd
