#!/bin/bash

. TOOLS/SETUP/env
. TOOLS/SETUP/config/config

MYSERVER_TOP=`pwd`
echo $MYSERVER_TOP


# システム情報を書き出す

echo "export USE_LB=${USE_LB}" > myserver.env
echo "export USE_STORAGE=${USE_STORAGE}" >> myserver.env
echo "export USE_MQTT=${USE_MQTT}" >> myserver.env
echo "export USE_IOT_COLLECTOR=${USE_IOT_COLLECTOR}" >> myserver.env
echo "export USE_IOT_DISTRIBUTOR=${USE_IOT_DISTRIBUTOR}" >> myserver.env
echo "export USE_IOT_AUTOMATE=${USE_IOT_AUTOMATE}" >> myserver.env
echo "export USE_FILEVIEW=${USE_FILEVIEW}" >> myserver.env
echo "export USE_AI=${USE_AI}" >> myserver.env
echo "export USE_PETWATCHER=${USE_PETWATCHER}" >> myserver.env
echo "export USE_MONITOR_CAMERA=${USE_MONITOR_CAMERA}" >> myserver.env
echo "export USE_MONITOR_SENSOR=${USE_MONITOR_SENSOR}" >> myserver.env
echo "export USE_MONITOR_DISTANCE=${USE_MONITOR_DISTANCE}" >> myserver.env


echo "export MYSERVER_ROOT=$MYSERVER_TOP" >> myserver.env
echo "export MYSERVER_DATA=$MYSERVER_TOP/data" >> myserver.env
echo "export MYSERVER_LOG=$MYSERVER_TOP/log" >> myserver.env
echo "export MYSERVER_SERVICE_ROOT=${MYSERVER_TOP}/${SRVTOP}" >> myserver.env

echo "export MYSERVER_EVENT_TOP=${SRVTOP}/Event"

echo "export MYSERVER_STORAGE_SERVICE_URL=http://${LB_STORAGE_SERVICE_HOST}:${LB_STORAGE_SERVICE_PORT}" >> myserver.env
echo "export MYSERVER_STORAGE_SERVER_1_URL=http://${STORAGE_SERVICE_HOST}:${STORAGE_SERVICE_PORT}" >> myserver.env
if [ $STORAGE_SERVER_NUM -gt 1 ]
then
    echo "export MYSERVER_STORAGE_SERVER_2_URL=http://${STORAGE_SERVICE_2_HOST}:${STORAGE_SERVICE_2_PORT}" >> myserver.env
fi
echo "export MYSERVER_IOT_COLLECTOR_URL=http://${COLLECTOR_HOST}:${COLLECTOR_PORT}" >> myserver.env
echo "export MYSERVER_IOT_DISTRIBUTOR_URL=http://${DISTRIBUTOR_HOST}:${DISTRIBUTOR_PORT}" >> myserver.env
echo "export MYSERVER_IOT_AUTOMATE_URL=http://${AUTOMATE_HOST}:${AUTOMATE_PORT}" >> myserver.env
echo "export MYSERVER_MQTT=tcp://${BROKER_HOST}:${BROKER_PORT}" >> myserver.env
echo "export MONITOR_WORK=$MYSERVER_TOP/${PETWATCHERTOP}/MONITOR/work" >> myserver.env
echo "export PETWATCHER_ACTION_BASE=$MYSERVER_TOP/${PETWATCHERTOP}/Automate/" >> myserver.env
echo "export MYSERVER_AUTOMATE_CONFIG_PATH=$MYSERVER_TOP/${PETWATCHERTOP}/Automate/" >> myserver.env
echo "export PETWATCHER_TOOLS_PATH=$MYSERVER_TOP/${PETWATCHERTOP}/tools" >> myserver.env
echo "export PETWATCHER_MONITOR_INFO=$MYSERVER_TOP/${PETWATCHERTOP}/APP/MONITOR_INFO" >> myserver.env

. myserver.env

#MYSERVER_TOP=`pwd`
#STORAGE_DATA=$MYSERVER_TOP/data

if [ "x$STORAGE_DATA_STORE" = "x" ]
then
    STORAGE_DATA_STORE=$MYSERVER_DATA/Storage/
    mkdir -p $STORAGE_DATA_STORE
fi

if [ "$USE_LB" != "YES" ]
then
    LB_STORAGE_SERVICE_HOST=$STORAGE_SERVICE_HOST
    LB_STORAGE_SERVICE_PORT=$STORAGE_SERVICE_PORT
fi


function rep_server () {
    TEMPLATE=$1
    OUTPUT=$2

    cat $TEMPLATE \
	 | sed s/__LB_STORAGE_SERVICE_HOST__/$LB_STORAGE_SERVICE_HOST/g \
	 | sed s/__LB_STORAGE_SERVICE_PORT__/$LB_STORAGE_SERVICE_PORT/g \
	 | sed s/__COLLECTOR_HOST__/$COLLECTOR_HOST/g \
	 | sed s/__COLLECTOR_PORT__/$COLLECTOR_PORT/g \
	 | sed s/__COLLECTOR_RETRY_MAX__/$COLLECTOR_RETRY_MAX/g \
	 | sed s/__COLLECTOR_RETRY_INTERVAL__/$COLLECTOR_RETRY_INTERVAL/g \
	 | sed s/__DISTRIBUTOR_HOST__/$DISTRIBUTOR_HOST/g \
	 | sed s/__DISTRIBUTOR_PORT__/$DISTRIBUTOR_PORT/g \
	 | sed s/__AUTOMATE_HOST__/$AUTOMATE_HOST/g \
	 | sed s/__AUTOMATE_PORT__/$AUTOMATE_PORT/g \
	 | sed s/__AUTOMATE_RETRY_MAX__/$AUTOMATE_RETRY_MAX/g \
	 | sed s/__AUTOMATE_RETRY_INTERVAL__/$AUTOMATE_RETRY_INTERVAL/g \
	 | sed s/__BROKER_HOST__/$BROKER_HOST/g \
	 | sed s/__BROKER_PORT__/$BROKER_PORT/g \
	 | sed s!__COLLECTOR_SAVE_TOPIC__!$COLLECTOR_SAVE_TOPIC!g \
	 | sed s!__COLLECTOR_SAVE_FOLDER__!$COLLECTOR_SAVE_FOLDER!g \
	 | sed s!__COLLECTOR_IN_TOPIC__!$COLLECTOR_IN_TOPIC!g \
	 | sed s!__COLLECTOR_OUT_TOPIC__!$COLLECTOR_OUT_TOPIC!g \
	 | sed s!__DISTRIBUTOR_IN_FOLDER__!$DISTRIBUTOR_IN_FOLDER!g \
	 | sed s!__DISTRIBUTOR_OUT_TOPIC__!$DISTRIBUTOR_OUT_TOPIC!g \
	 | sed s!__AUTOMATE_IN_TOPIC__!$AUTOMATE_IN_TOPIC!g \
	 | sed s!__AUTOMATE_OUT_TOPIC__!$AUTOMATE_OUT_TOPIC!g \
	 | sed s!__FILEVIEW_PORT__!$FILEVIEW_PORT!g \
	 | sed s!__MYSERVER_STORAGE_SERVICE_URL__!$MYSERVER_STORAGE_SERVICE_URL!g \
	 | sed s!__VISIONKIT_HOST__!$VISIONKIT_HOST!g \
	 | sed s!__VISIONKIT_PORT__!$VISIONKIT_PORT!g \
	 | sed s!__VISIONKIT_USER__!$VISIONKIT_USER!g \
	 | sed s!__VISIONKIT_PASSWORD__!$VISIONKIT_PASSWORD!g \
	 | sed s!__MONITOR_WORK__!$MONITOR_WORK!g \
	 | sed s!__PETWATCHER_PORT__!$PETWATCHER_PORT!g \
	 | sed s!__PETWATCHER_ACTION_BASE__!$PETWATCHER_ACTION_BASE!g \
	 | sed s!__AUTOMATE_DISTANCECHECK_IN_TOPIC__!$AUTOMATE_DISTANCECHECK_IN_TOPIC!g \
	 | sed s!__AUTOMATE_DISTANCECHECK_OUT_TOPIC__!$AUTOMATE_DISTANCECHECK_OUT_TOPIC!g \
	 | sed s!__SRVTOP__!$SRVTOP!g \
	 | sed s!__AITOP__!$AITOP!g \
	 | sed s!__PETWATCHERTOP__!$PETWATCHERTOP!g \
	 | sed s!__PETWATCHER_MONITOR_INFO__!$PETWATCHER_MONITOR_INFO!g \
	 | sed s!__PETWATCHER_MONITOR_HOST__!$PETWATCHER_MONITOR_HOST!g \
	       > $OUTPUT
}

function rep_storage_server () {
    TEMPLATE=$1
    OUTPUT=$2
    SERVER_NUM=$3
    SERVER_NO=$4

    # 基本設定
    if [ $SERVER_NO = 0 ]
    then
	cat $TEMPLATE \
	     | sed s/__STORAGE_SERVICE_HOST__/$STORAGE_SERVICE_HOST/g \
		 | sed s/__STORAGE_SERVICE_PORT__/$STORAGE_SERVICE_PORT/g \
		 | sed s!__STORAGE_DATA_STORE__!$STORAGE_DATA_STORE!g \
		 | sed s!__STORAGE_SERVICE_USER__!$STORAGE_SERVICE_USER!g \
		 | sed s!__STORAGE_SERVICE_PASSWORD__!$STORAGE_SERVICE_PASSWORD!g \
		 | sed s!__SRVTOP__!$SRVTOP!g \
		 | sed s!__AITOP__!$AITOP!g \
		 | sed s!__PETWATCHERTOP__!$PETWATCHERTOP!g \
		       > $OUTPUT.tmp
    elif [ $SERVER_NO = 1 ]
    then
	cat $TEMPLATE \
	     | sed s/__STORAGE_SERVICE_HOST__/$STORAGE_SERVICE_2_HOST/g \
		 | sed s/__STORAGE_SERVICE_PORT__/$STORAGE_SERVICE_2_PORT/g \
		 | sed s!__STORAGE_DATA_STORE__!$STORAGE_DATA_STORE!g \
		 | sed s!__STORAGE_SERVICE_USER__!$STORAGE_SERVICE_USER!g \
		 | sed s!__STORAGE_SERVICE_PASSWORD__!$STORAGE_SERVICE_PASSWORD!g \
		 | sed s!__SRVTOP__!$SRVTOP!g \
		 | sed s!__AITOP__!$AITOP!g \
		 | sed s!__PETWATCHERTOP__!$PETWATCHERTOP!g \
		       > $OUTPUT.tmp
    fi


    # サーバリスト
    if [ $SERVER_NUM = 1 ]
    then
	SERVERS="[{\"host\":\"$STORAGE_SERVICE_HOST\",\"port\":$STORAGE_SERVICE_PORT}]"
    else
	SERVERS="[{\"host\":\"$STORAGE_SERVICE_HOST\",\"port\":$STORAGE_SERVICE_PORT},{\"host\":\"$STORAGE_SERVICE_2_HOST\",\"port\":$STORAGE_SERVICE_2_PORT}]"
    fi
    cat $OUTPUT.tmp | sed s!__SERVERS__!$SERVERS!g  > $OUTPUT
    

    rm -f $OUTPUT.tmp
    
}


function rep_event () {
    TEMPLATE=$1
    OUTPUT=$2
    
    cat $TEMPLATE \
	     | sed s!__FUNCTION_BASE__!$FUNCTION_BASE!g \
	     | sed s!__SRVTOP__!$SRVTOP!g \
	     | sed s!__AITOP__!$AITOP!g \
	     | sed s!__PETWATCHERTOP__!$PETWATCHERTOP!g \
		       > $OUTPUT

}


function rep_lb_config () {
    TEMPLATE=$1
    OUTPUT=$2
    SERVER_NUM=$3
    LB_USER=$4
    LB_GROUP=$5
    LB_ROOT=$6

    cat $TEMPLATE \
	 | sed s/__LB_SERVICE_HOST__/$LB_SERVICE_HOST/g \
	 | sed s/__LB_SERVICE_PORT__/$LB_SERVICE_PORT/g \
	 | sed s/__LB_STORAGE_SERVICE_HOST__/$LB_STORAGE_SERVICE_HOST/g \
	 | sed s/__LB_STORAGE_SERVICE_PORT__/$LB_STORAGE_SERVICE_PORT/g \
	 | sed s/__LB_USER__/$LB_USER/g \
	 | sed s/__LB_GROUP__/$LB_GROUP/g \
	 | sed s!__LB_ROOT__!$LB_ROOT!g \
	       > $OUTPUT.tmp

    SERVER1="server          MYSRV1 $STORAGE_SERVICE_HOST:$STORAGE_SERVICE_PORT minconn 200 maxconn 1000 cookie s1 check inter 5000"
    SERVER_S1="server          MYSSRV1 $STORAGE_SERVICE_HOST:$STORAGE_SERVICE_PORT minconn 200 maxconn 1000 cookie ss1 check inter 5000"
    SERVER2=""
    SERVER_S2=""
    if [ $SERVER_NUM -gt 1 ]
    then
	SERVER2="server          MYSRV2 $STORAGE_SERVICE_2_HOST:$STORAGE_SERVICE_2_PORT minconn 200 maxconn 1000 cookie s2 check inter 5000"
	SERVER_S2="server          MYSSRV2 $STORAGE_SERVICE_2_HOST:$STORAGE_SERVICE_2_PORT minconn 200 maxconn 1000 cookie ss2 check inter 5000"
    fi

    cat $OUTPUT.tmp | sed "s/__SERVER1__/$SERVER1/g"  | sed "s/__SERVER2__/$SERVER2/g" \
	 | sed "s/__SERVER_S1__/$SERVER_S1/g"  | sed "s/__SERVER_S2__/$SERVER_S2/g"   > $OUTPUT

    rm $OUTPUT.tmp

}


# LB
LB_USER=`id -u`
LB_GROUP=`id -g`
LB_ROOT=$MYSERVER_TOP/work/
mkdir -p $LB_ROOT

rep_lb_config $MYSERVER_TOP/LB/myserver_lb.cfg.template $MYSERVER_TOP/LB/myserver_lb.cfg $STORAGE_SERVER_NUM $LB_USER $LB_GROUP $LB_ROOT


# Storage Service

rep_storage_server $MYSERVER_TOP/$SRVTOP/Storage/config.json.template $MYSERVER_TOP/$SRVTOP/Storage/config.json $STORAGE_SERVER_NUM $STORAGE_NO


# IoT Service
rep_server $MYSERVER_TOP/$SRVTOP/IoT/Automate/config.json.template $MYSERVER_TOP/$SRVTOP/IoT/Automate/config.json
rep_server $MYSERVER_TOP/$SRVTOP/IoT/MessageCollector/config.json.template $MYSERVER_TOP/$SRVTOP/IoT/MessageCollector/config.json
rep_server $MYSERVER_TOP/$SRVTOP/IoT/MessageDistributor/config.json.template $MYSERVER_TOP/$SRVTOP/IoT/MessageDistributor/config.json


# Function
rep_server $MYSERVER_TOP/$SRVTOP/Function/move_bydate/config.json.template $MYSERVER_TOP/$SRVTOP/Function/move_bydate/config.json
 
# Event
rep_event $MYSERVER_TOP/$SRVTOP/Event/create_file/config.json.template $MYSERVER_TOP/$SRVTOP/Event/create_file/config.json
rep_event $MYSERVER_TOP/$SRVTOP/Event/delete_file/config.json.template $MYSERVER_TOP/$SRVTOP/Event/delete_file/config.json


# MQTT Broker


# FileView
rep_server $MYSERVER_TOP/$APPTOP/FileView/CONFIG/config.json.template $MYSERVER_TOP/$APPTOP/FileView/CONFIG/config.json

# AI
rep_server $MYSERVER_TOP/$AITOP/classification/config.json.template $MYSERVER_TOP/$AITOP/classification/config.json
rep_server $MYSERVER_TOP/$AITOP/classification/vk_config.json.template $MYSERVER_TOP/$AITOP/classification/vk_config.json

# PetWatcher
rep_server $MYSERVER_TOP/$PETWATCHERTOP/APP/CONFIG/config.json.template $MYSERVER_TOP/$PETWATCHERTOP/APP/CONFIG/config.json
rep_server $MYSERVER_TOP/$PETWATCHERTOP/APP/MONITOR_INFO/RASPI_MON.template $MYSERVER_TOP/$PETWATCHERTOP/APP/MONITOR_INFO/MONITOR/RASPI_MON
rep_server $MYSERVER_TOP/$PETWATCHERTOP/Automate/distance_check.config.template $MYSERVER_TOP/$PETWATCHERTOP/Automate/distance_check.config
rep_server $MYSERVER_TOP/$PETWATCHERTOP/Automate/action.config.template $MYSERVER_TOP/$PETWATCHERTOP/Automate/action.config
rep_server $MYSERVER_TOP/$PETWATCHERTOP/MONITOR/config.json.template $MYSERVER_TOP/$PETWATCHERTOP/MONITOR/config.json
rep_server $MYSERVER_TOP/$PETWATCHERTOP/MONITOR/vk_config.json.template $MYSERVER_TOP/$PETWATCHERTOP/MONITOR/vk_config.json
rep_server $PETWATCHER_TOOLS_PATH/CONFIG.template $PETWATCHER_TOOLS_PATH/CONFIG

