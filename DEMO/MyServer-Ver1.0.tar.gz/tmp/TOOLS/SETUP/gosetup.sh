#!/bin/bash

MYSERVER_TOP=$1

if [ "x$MYSERVER_TOP" = "x" ]
then
    exit 1
fi


GO_VER=1.15.6
#GO_VER=1.11.1
#GO_VER=1.7.4

#ARC=linux-amd64
ARC=linux-armv6l
#ARC=darwin-amd64
GO_FILE=go${GO_VER}.${ARC}.tar.gz
GO_URL=https://dl.google.com/go/${GO_FILE}

if [ -f $MYSERVER_TOP/goenv.sh ]; then
    echo "Already installed Go."
    exit 0
fi

mkdir -p $MYSERVER_TOP/golang
mkdir -p $MYSERVER_TOP/golang/gopath

pushd $MYSERVER_TOP/download
wget  -nc -q $GO_URL
popd

pushd $MYSERVER_TOP/golang
tar zxf $MYSERVER_TOP/download/$GO_FILE
popd

ENVFILE=$MYSERVER_TOP/goenv.sh
echo "export MYSERVER_TOP=$MYSERVER_TOP" > $ENVFILE
echo 'export GOROOT=$MYSERVER_TOP/golang/go' >> $ENVFILE
echo 'export GOPATH=$MYSERVER_TOP/golang/gopath' >> $ENVFILE
echo 'export PATH=$GOROOT/bin:$PATH' >> $ENVFILE


