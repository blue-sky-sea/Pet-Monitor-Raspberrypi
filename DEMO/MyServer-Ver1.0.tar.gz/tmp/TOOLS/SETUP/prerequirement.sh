#!/bin/bash

$SUDO apt-get update
$SUDO apt-get install -y git
$SUDO apt-get install -y wget
$SUDO apt-get install -y curl
$SUDO apt-get install -y build-essential
$SUDO apt-get install -y xz-utils

$SUDO apt install -y libffi-dev libssl-dev

# for HAProxy
$SUDO apt install -y libpcre3 libpcre3-dev

# for Erlang,EMQ
$SUDO apt install -y libncurses5-dev libssl-dev
