#!/bin/bash

go get github.com/labstack/echo
go get github.com/dgrijalva/jwt-go
go get github.com/tmc/scp
go get github.com/eclipse/paho.mqtt.golang
go get github.com/rwcarlsen/goexif/exif
go get golang.org/x/crypto/ssh
go get golang.org/x/time/rate
