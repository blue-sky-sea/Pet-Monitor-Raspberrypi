#!/bin/bash

OLD_IP="10.1.99.117"
NEW_IP="192.168.2.8"

FILE=./SETUP/config/config

sed s/$OLD_IP/$NEW_IP/g ${FILE} > ${FILE}_new
if [ $? = 0 ];then
    echo "rewrite config $OLD_IP -> $NEW_IP"
    mv ${FILE}_new $FILE
fi

