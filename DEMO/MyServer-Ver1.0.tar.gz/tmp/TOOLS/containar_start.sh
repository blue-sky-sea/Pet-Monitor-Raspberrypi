#!/bin/bash

#コンテナ環境でMyサーバを起動する
# パターン１：複数コンテナ
#  Container1) LB, MQTT Broker, StorageServer, IoT MessageCollector, MessageDistributor, Automate
# パターン２：複数コンテナ
#  Container1) LB, MQTT Broker
#  Container2) StorageServer-1
#  Container3) StorageServer-2
#  Container4) IoT MessageCollector,MessageDistributor,Automate

#外部に開けるポート
#LB
#	ストレージサービス　→  3000
#	サービス　　　　　　→  3001

#MQTT Broker
#	ポート　　　　　　　→  1883


#docker 
#-p 外部ポート:内部ポート　でポートフォワード設定
#-v ホストのパス:コンテナのパス　でホストとコンテナでディレクトリを共有できる

docker run -i -t -p 3000:3000 -p 3001:3001 -p 1883:1883 -v `pwd`/sharedFolder:/sharedFolder ubuntu

