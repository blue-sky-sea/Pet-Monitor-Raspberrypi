#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
import datetime
import json
import sys
import os.path


#
# 共通関数
#

debug_mode = True
config = {}

# configファイルのロード
def load_config(path='./config.json'):
    global config
    f = open(path, 'r')
    config = json.load(f)
    f.close()
    if debug_mode:
        print(config)


def id():
    return config['client_id']

def work_dir():
    return config['work_dir']

def storage():
    return config['storage_url']

def mqtt():
    return config['mqtt_broker']

def interval():
    return config['interval']

def app_id():
    return config['APP']

def pic_size():
    return config['pic_size']

def topic_monitor():
    return config['topic_monitor']

def topic_event():
    return config['topic_event']

def save_path(dt_now=None):
    # アプリID/MONITOR/自分のID/年/月/日/時刻/
    if dt_now == None:
        dt_now = datetime.datetime.now()

    return os.path.join(app_id(), 'MONITOR', id(), dt_now.strftime('%Y/%m/%d/%H%M%S'))

def monitor_picture_path(dt_now=None, name='picture.jpeg'):
    return os.path.join(save_path(), name)

def monitor_sensor_path(dt_now=None, name='sensor.json'):
    return os.path.join(save_path(), name)

def cat_only():
    return config['cat_only']




if __name__ == '__main__':

    load_config('./config.json')

    print(config)

    print(id())
    print(storage())
    print(mqtt())
    print(interval())
    print(app_id())
    print(save_path())
    print(monitor_picture_path())
    print(monitor_sensor_path())
