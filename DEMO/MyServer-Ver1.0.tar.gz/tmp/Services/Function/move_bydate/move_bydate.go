// https://github.com/rwcarlsen/goexif

/*


環境変数で、MyServerのトップディレクトリを指定することにする。

MYSERVER_ROOT

それを使って、ファイルの場所などを見つけることにする。


必要パッケージのインストール
go get github.com/rwcarlsen/goexif/exif



*/

package main

import (
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/rwcarlsen/goexif/exif"
	"github.com/rwcarlsen/goexif/mknote"
)

var (
	myserver_root = "./"
	log_dir = "./"
	photo_top     = "/MyPhoto"
	server        = "localhost"
	port          = 3001
)

func getDate(file string) (int, int, int, int, int, int) {

	f, err := os.Open(file)
	if err != nil {
		log.Fatal(err)
		return 0, 0, 0, 0, 0, 0
	}
	defer f.Close()

	exif.RegisterParsers(mknote.All...)

	info, err := exif.Decode(f)
	if err != nil {
		log.Fatal(err)
		return 0, 0, 0, 0, 0, 0
	}

	// 撮影日時取得
	tm, _ := info.DateTime()
	fmt.Println("Taken: ", tm)

	fmt.Println("Year: ", tm.Year())
	fmt.Println("Month: ", int(tm.Month()))
	fmt.Println("Day: ", tm.Day())
	fmt.Println("Hour: ", tm.Hour())
	fmt.Println("Minute ", tm.Minute())
	fmt.Println("Second: ", tm.Second())

	return tm.Year(), int(tm.Month()), tm.Day(), tm.Hour(), tm.Minute(), tm.Second()

}

/*
 configファイルの情報を保持する構造体
*/
type Config struct {
	Api_host string `json:"api_host"`
	Api_port uint16 `json:"api_port"`
}

func main() {

	// プログラム配置場所のTOPを取得
	wk := os.Getenv("MYSERVER_ROOT")
	if wk != "" {
		myserver_root = wk
	}

	// ログ出力準備
	wk = os.Getenv("MYSERVER_LOG")
	if wk != "" {
	   log_dir = wk
	}
	fmt.Println("MYSERVER_ROOT = ", myserver_root)
	fmt.Println("MYSERVER_LOG  = ", log_dir)
	dir := filepath.Join(log_dir, "MyFunction")
	_, err := os.Stat(dir)
	if os.IsNotExist(err) {
		err = os.MkdirAll(dir, 0775)
		if err != nil {
			fmt.Println("failed to create directory: " + dir)
			panic("cannnot create " + dir + " : " + err.Error())
		}
	}
	logfile, err := os.OpenFile(filepath.Join(dir, "move_bydate"),
		os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0666)
	if err != nil {
		panic("cannnot open test.log:" + err.Error())
	}
	defer logfile.Close()
	log.SetOutput(io.MultiWriter(logfile, os.Stdout))
	log.SetFlags(log.Ldate | log.Ltime)

	// 引数解析
	if len(os.Args) != 3 {
		log.Println("Usage: " + filepath.Base(os.Args[0]) + " <data store>> <file>")
		os.Exit(1)
	}
	data_store := os.Args[1]
	log.Println(data_store)
	file_path := os.Args[2]
	log.Println(file_path)

	// 設定ファイル
	prog_dir := filepath.Dir(os.Args[0])
	config_path := filepath.Join(prog_dir, "config.json")
	log.Println(config_path)

	// 設定ファイルを読み込む
	conf := new(Config)
	conf_file, err := ioutil.ReadFile(config_path)
	if err != nil {
		log.Println("Config file read error.")
		os.Exit(1)
	}
	err = json.Unmarshal(conf_file, conf)
	log.Println(err)
	if err != nil {
		log.Println("Config file parse error.")
		os.Exit(1)
	}
	log.Println("conf = ", *conf)
	server = conf.Api_host
	port = int(conf.Api_port)

	// EXIFから撮影日を取得する
	year, month, day, hour, minute, second := getDate(file_path)
	log.Println(year, month, day, hour, minute, second)

	// ファイル名を取得
	file_name := strings.Replace(file_path, data_store, "/", 1)
	log.Println("file_name = ", file_name)

	/* 保存先のパスを組み立てる
	撮影日 + ファイル名 => 年/月/日/ファイル名
	*/
	new_name := strings.Replace(file_name, "/ClassifyByDate/", "/", 1)
	log.Println("new_name = ", new_name)
	new_path := filepath.Join(photo_top, strconv.Itoa(year), strconv.Itoa(month), strconv.Itoa(day), new_name)
	log.Println("new_path = ", new_path)

	// ストレージ・サービスにリネーム・リクエスト
	client := &http.Client{}
	url := "http://" + server + ":" + strconv.Itoa(port) + "/storage/" + file_name + "?rename=" + new_path
	log.Println("url = ", url)
	req, err := http.NewRequest("PUT", url, strings.NewReader("")) // 今回はbodyはなし
	if err != nil {
		log.Println("http.NewRequest Failed:", err)
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	res, err := client.Do(req)
	if err != nil {
		log.Println("client.Do Failed:", err)
	} else {
		defer res.Body.Close()
	}

	/*
	   参考
	   http://blog.sarabande.jp/post/90736041568
	   https://golang.org/pkg/net/http/

	*/

}
