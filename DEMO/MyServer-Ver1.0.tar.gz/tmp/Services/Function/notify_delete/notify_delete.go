package main

import (
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
)

var (
	myserver_root = "./"
	log_dir = "./"
)

func main() {

	// プログラム配置場所のTOPを取得
	wk := os.Getenv("MYSERVER_ROOT")
	if wk != "" {
		myserver_root = wk
	}

	// ログ出力準備
	wk = os.Getenv("MYSERVER_LOG")
	if wk != "" {
	   log_dir = wk
	}
	fmt.Println("MYSERVER_ROOT = ", myserver_root)
	fmt.Println("MYSERVER_LOG  = ", log_dir)
	dir := filepath.Join(log_dir, "MyFunction")
	_, err := os.Stat(dir)
	if os.IsNotExist(err) {
		err = os.MkdirAll(dir, 0775)
		if err != nil {
			fmt.Println("failed to create directory: " + dir)
			panic("cannnot create " + dir + " : " + err.Error())
		}
	}
	logfile, err := os.OpenFile(filepath.Join(dir, "notify_delete"),
		os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0666)
	if err != nil {
		panic("cannnot open test.log:" + err.Error())
	}
	defer logfile.Close()
	log.SetOutput(io.MultiWriter(logfile, os.Stdout))
	log.SetFlags(log.Ldate | log.Ltime)

	// 引数解析
	if len(os.Args) != 3 {
		log.Println("Usage: " + filepath.Base(os.Args[0]) + "<data store>> <file>")
		os.Exit(1)
	}
	data_store := os.Args[1]
	log.Println(data_store)
	file_name := os.Args[2]
	log.Println(file_name)

	/*
	   ここに、ファイル削除時の通知処理を記述する
	*/

}
