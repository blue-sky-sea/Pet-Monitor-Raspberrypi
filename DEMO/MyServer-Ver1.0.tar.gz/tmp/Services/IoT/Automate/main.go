package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"time"
	"context"
	"flag"

	"github.com/labstack/echo"
	"github.com/labstack/echo/middleware"
)

const (
	CMD_QUIT = "quit"
)

var (
	myserver_root = "./"
	srv_fin_chan      = make(chan string, 1)
	debug_mode    = true
)

// 設定情報
type Config struct {
	Host        string           `json:"host"`
	Port        uint16           `json:"port"`
	Control_url string           `json:"control_url"`
	Actions     []ExecutorAction `json:"actions"`
}

// リクエストハンドラ：バージョン返却
func requestHandler(c echo.Context) error {
	return c.String(http.StatusOK, "IoT Automation Ver0.5")
}

// リクエストハンドラ：プログラムコントロール
func controlHandler(c echo.Context) error {
	if debug_mode {
		fmt.Println("control handler")
	}
	// コマンド名取得
	cmd := c.FormValue("command")
	// コマンド毎の処理
	switch cmd {
	case CMD_QUIT: // プログラムの終了
		if debug_mode {
			fmt.Println(CMD_QUIT)
		}
		// 自動処理を停止
		stopExecutor()
		// プログラム終了通知
		srv_fin_chan <- "fin"
	}
	return c.NoContent(http.StatusOK)
}

// メイン処理
func main() {

	// プログラム配置場所のTOPを取得
	myserver_root = os.Getenv("MYSERVER_ROOT")
	log.Println("MYSERVER_ROOT = ", myserver_root)

	// オプション解析
	opt_config := flag.String("config", "./config.json", "config file path.")
	flag.Parse()

	/*** プログラム動作の設定ロード ***/
	// 設定ファイルを読み込むパスを設定
	config_path := *opt_config
	if config_path == "" {
		prog_dir := filepath.Dir(os.Args[0])
		config_path = filepath.Join(prog_dir, "config.json")
	}
	log.Println("config file:", config_path)
	// 設定ファイルを読み込む
	conf := new(Config)
	conf_file, err := ioutil.ReadFile(config_path)
	if err != nil {
		log.Println("Config file read error. - ", err)
		os.Exit(1)
	}
	err = json.Unmarshal(conf_file, conf)
	if debug_mode {
		fmt.Println(conf)
	}

	/*** 自動実行処理エンジンの起動 ***/
	// アクション実行Goルーチンの起動
	for no, act := range conf.Actions {
		fmt.Println(no, "execute action of ", act)
		go MQTTMessageProcessor(act)
	}

	/*** コントロール用のAPIサーバ初期化 ***/
	// Echoセットアップ
	e := echo.New()

	// アクセスログの設定
	e.Use(middleware.Logger())

	// エラー発生時の対処設定
	e.Use(middleware.Recover())

	// ブラウザからjavascriptを使ってAPI呼び出しできるようにCORS対応
	e.Use(middleware.CORSWithConfig(middleware.CORSConfig{
		AllowOrigins: []string{"*"},
		AllowMethods: []string{echo.GET, echo.PUT, echo.POST, echo.DELETE, echo.HEAD},
	}))

	// リクエストハンドラ登録
	e.GET("/", requestHandler)
	e.POST(conf.Control_url, controlHandler)

	// サーバの起動
	go e.Start(conf.Host + ":" + strconv.FormatInt(int64(conf.Port), 10))

	// プログラム終了通知を待つ
	_ = <-srv_fin_chan

	// 処理停止
	ctx, cancel_fn := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel_fn()
	e.Shutdown(ctx)
}
