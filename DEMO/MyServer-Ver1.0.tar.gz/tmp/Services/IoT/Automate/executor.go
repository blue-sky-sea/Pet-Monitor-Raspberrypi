package main

import (
	"fmt"
	"os/exec"
	"time"
	"math"

	MQTT "github.com/eclipse/paho.mqtt.golang"
)

var (
	cmd_chan      = make(chan string)
	fin_chan      = make(chan string)
	actions       = make(map[string]*ExecutorAction)
	processor_num = 0
)

// 自動実行の設定
type ExecutorAction struct {
	Base      string   `json:"base"`
	InBroker  string   `json:"in_broker"`
	InTopic   string   `json:"in_topic"`
	OutBroker string   `json:"out_broker"`
	OutTopic  string   `json:"out_topic"`
	Commands  []string `json:"commands"`
	RetryMax  int      `json:"retry_max"`
	RetryInterval  int      `json:"retry_interval"`
}

// 自動実行アクション実行Goルーチンの停止
func stopExecutor() {
	// MQTTMessageProcessorへ停止リクエストを送る
	for i := 0; i < processor_num; i++ {
		cmd_chan <- "quit"
	}

	// 全てのMQTTMessageProcessorが終了するのを待つ
	for {
		// MQTTMessageProcessorがいなくなれば終了
		if processor_num == 0 {
			break
		}
		fmt.Println("call <- fin_chan")
		_ = <-fin_chan
		// 今は、メッセージを受け取らないで、ただタイミングをとるだけ
		processor_num--
	}
}

// MQTT接続クライアントの準備
func getMQTTClient(broker_addr string, client_id string) MQTT.Client {

	if debug_mode {
		fmt.Println("getMQTTClient:", broker_addr, client_id)
	}
	// MQTTへの接続設定
	opts := MQTT.NewClientOptions()
	broker := "tcp://" + broker_addr
	opts.AddBroker(broker)
	opts.SetClientID(client_id)
//	opts.SetCleanSession(false)	//??
	opts.SetCleanSession(true)	//??
	opts.SetAutoReconnect(false)
	opts.SetConnectionLostHandler(connectionLost)

	// MQTTクライアントの作成
	client := MQTT.NewClient(opts)

	return client
}

// MQTTパブリッシュ処理
func publishMessage(action *ExecutorAction, msg []byte) error {
	if debug_mode {
		fmt.Println("publishMessage:", action)
	}
	// 送信用クライアントの準備
	client := getMQTTClient(action.OutBroker, action.OutTopic)
	if debug_mode {
		fmt.Println("publishMessage:", client)
	}
	// MQTT Brokerへ接続
	if token := client.Connect(); token.Wait() && token.Error() != nil {
		fmt.Println("publishMessage: MQTT client setup failed.", token.Error())
		return token.Error()
	}
	fmt.Println("publishMessage", string(msg), "->", "tcp://"+action.OutBroker, action.OutTopic)

	// パブリッシュ
	if token := client.Publish(action.OutTopic, byte(0), false, string(msg)); token.Wait() && token.Error() != nil {
		err := token.Error()
		fmt.Println("publishMessage: publish message failed.", err)
		return err
	} else {
		client.Disconnect(250)
		return nil
	}
}

// メッセージを受け取った時に起動されるハンドラ
func messageHandler(client MQTT.Client, msg MQTT.Message) {

	if debug_mode {
		fmt.Println("messageHandler:", client, msg)
	}

	// クライアントIDをキーにアクション設定を取り出す
	cor := client.OptionsReader()
	action, _ := actions[cor.ClientID()]

	if debug_mode {
		fmt.Println("messageHandler: action=", action)
	}

	// メッセージを受け取ったら登録処理を実行
	out, err := executor(action, msg.Payload())
	if debug_mode {
		fmt.Println("messageHandler: out=", out, err)
	}

	// MQTT Brokerにメッセージを送る
	publishMessage(action, out)

}

//コネクション切断時のコールバック
func connectionLost(client MQTT.Client, e error) {

	if debug_mode {
		fmt.Println("connectionLost:", client, e)
	}

	// client->action
     cor := client.OptionsReader()
     action, _ := actions[cor.ClientID()]

if debug_mode {
		fmt.Println("connectionLost:", action)
	}
     

     client.Disconnect(250)
     
     // 再初期化
     go MQTTMessageProcessor(*action)
     
}


// メッセージを処理する
func MQTTMessageProcessor(action ExecutorAction) {

	if debug_mode {
		fmt.Println("MQTTMessageProcessor:", action)
	}
	// 受信用クライアントの準備
	client := getMQTTClient(action.InBroker, action.InTopic)
	if debug_mode {
		fmt.Println(client)
	}
	// MQTT Brokerへ接続
	retry_max := action.RetryMax
	if retry_max == 0 {
	   retry_max = math.MaxInt32
	}
	for retry_cnt := 0 ;; {
	    if token := client.Connect(); token.Wait() && token.Error() == nil {
	    	if debug_mode {
	    	   fmt.Println("Executor: MQTT client setup complete")
		}
	       break
	    }
	    
	    if retry_cnt == retry_max {
	       fmt.Println("Executor: MQTT client setup failed")
	       break;
	    }
	    if debug_mode {
		fmt.Println("Executor: MQTT client setup error and retry. Sleep ", action.RetryInterval, "seconds.")
		}
	    // wait
	    time.Sleep(time.Duration(action.RetryInterval) * time.Second)
	    
	    // counter
	    retry_cnt++
	}

	// ハンドラがExecutorActionを見つけられるように登録(クライアントIDをキーとする)
	cor := client.OptionsReader()
	actions[cor.ClientID()] = &action

	// メッセージハンドラとしてmessageHandler関数を登録し、メッセージ到着を受け付ける
	token := client.Subscribe(action.InTopic, byte(0), messageHandler)
	token.Wait()

	processor_num++

	// 終了通知まで寝てる
	select {
	case cmd := <-cmd_chan:
		// cmd判定で処理を変えることもできるが、今は終了のみなので判定しない
		fmt.Println(cmd)
		fmt.Println("stop MQTTMessageProcessor:", action)
		break
	}

	// 切断
	client.Disconnect(250)

	// 処理が終了したことを報告する
	fmt.Println("fin_chan <- \"fin\"")
	fin_chan <- "fin"

}

// 自動処理のエンジン
func executor(action *ExecutorAction, data []byte) ([]byte, error) {

	// 入力データ準備
	out_data := data

	/*
	  ExecutorActionで設定されている、プログラム・チェーンにしたがって順次実行する
	  (プログラムは標準入力からデータを読み、加工後、標準出力にデータを書き込むルールで実装)
	*/
	for i, prog := range action.Commands {
		// 実行するプログラムのパスを設定
		prog = action.Base + prog
		if debug_mode {
			fmt.Println(i, "execute :", prog)
		}

		// プログラムへの入力データをセット
		in_data := out_data

		// プログラム実行準備
		cmd := exec.Command(prog)
		// 標準入力を使ってデータを渡すので、その準備
		stdin, _ := cmd.StdinPipe()
		len, err := stdin.Write([]byte(in_data))
		if err != nil {
			fmt.Println("Failed to write stdin", err)
			return nil, err
		}
		stdin.Close()
		if debug_mode {
			fmt.Println(len, err)
		}

		// プログラムを実行して結果を受け取る(実行結果は標準出力から受け取る)
		out, err := cmd.Output()
		if debug_mode {
			fmt.Println("out = ", string(out))
		}
		if err != nil {
			fmt.Println("Failed to execute ", prog, err)
			return nil, err
		}

		// プログラムの出力結果をセット
		out_data = out
	}

	// 最終的な加工結果を返す
	return []byte(out_data), nil

}
