#!/bin/bash
#
# データ採取日時を追加するスクリプト
#

DATE=`date +"%Y.%m.%d %H:%M:%S"`

if [ -p /dev/stdin ]
then
    input=`perl -pe 's/[\n{}]//g'`
else
    input=`echo $@ | perl -pe 's/[\n{}]//g'`
fi

pres=`echo $input | awk -F, '{print($1)}'`
temp=`echo $input | awk -F, '{print($2)}'`
hum=`echo $input | awk -F, '{print($3)}'`

echo {
echo $pres,
echo $temp,
echo $hum,
echo '"time":"'$DATE'"'
echo }



