#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import json


def celsius2fahrenheit(c):
    f = c * 1.8 + 32
    return f

def celsius2kelvin(c):
    k = c + 273.15
    return k


#標準入力からJSONデータを読み込む
df = json.load(sys.stdin)

#今の値を取り出す
if 'temperature' in df:
    val = df['temperature']
    # temperature の値を摂氏から華氏に変換
    df['temperature'] = celsius2fahrenheit(val)
    # temperature の値を摂氏から絶対温度に変換
    #df['temperature'] = celsius2kelvin(val)

#標準出力にJSONデータを書き込む
json.dump(df,sys.stdout)

