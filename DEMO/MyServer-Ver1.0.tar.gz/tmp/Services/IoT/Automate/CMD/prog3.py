#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import json


#標準入力からJSONデータを読み込む
df = json.load(sys.stdin)

#小数点１位までの形式に合わせる
df['pressure'] = round(df['pressure'],1)
df['temperature'] = round(df['temperature'],1)
df['humidity'] = round(df['humidity'],1)


#標準出力にJSONデータを書き込む
json.dump(df,sys.stdout)

