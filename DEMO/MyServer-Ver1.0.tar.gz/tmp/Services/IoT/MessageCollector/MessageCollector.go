/*
 MessegeCollector

 メッセージ収集プログラム

*/

package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
	"context"
	"math"
	"flag"

	MQTT "github.com/eclipse/paho.mqtt.golang"

	"github.com/labstack/echo"
	"github.com/labstack/echo/middleware"
)

const (
	CONTROL_URL    = "/control"
	HOST           = "localhost"
	PORT           = uint16(4000)
	BROKER_HOST    = "localhost"
	BROKER_PORT    = uint16(1883)
	ACTION_SAVE    = "SAVE"
	ACTION_PUBLISH = "PUBLISH"
	CMD_QUIT       = "quit"
)

// 変数定義
var (
	myserver_root = "./"
	mqtt_client   = MQTT.Client(nil)
	http_client   = &http.Client{}
	publish_cliet = MQTT.Client(nil)
	actions       = make(map[string]Action)
	FileID        = make(map[string]uint64)
	fileid_mode   = false
	cmd_chan      = make(chan string, 1)
	fin_chan      = make(chan string, 1)
	srv_fin_chan      = make(chan string, 1)
	conf	 = new(Config)
	debug_mode    = true
)

// configファイルの情報を保持する構造体
type Action struct {
	Topic  string `json:"topic"`
	Action string `json:"action"`
	Target string `json:"target"`
	Name   string `json:"name"`
}
type Config struct {
	Host        string   `json:"host"`
	Port        uint16   `json:"port"`
	Broker_host string   `json:"broker_host"`
	Broker_port uint16   `json:"broker_port"`
	RetryMax  int      `json:"retry_max"`
	RetryInterval  int      `json:"retry_interval"`
	Control_url string   `json:"control_url"`
	Actions     []Action `json:actions`
}

// MQTTパブリッシュ処理
func publishMessage(action Action, msg MQTT.Message) error {
	// 送信準備
	opts := MQTT.NewClientOptions()
	opts.AddBroker("tcp://" + action.Target)
	opts.SetClientID("Message Collector")
	opts.SetCleanSession(false)

	if debug_mode {
		fmt.Println(opts)
	}

	client := MQTT.NewClient(opts)
	if token := client.Connect(); token.Wait() && token.Error() != nil {
		fmt.Println("publishMessage: MQTT client setup failed")
		return token.Error()
	}
	fmt.Println("publishMessage", msg.Topic(), "->", "tcp://"+action.Target, action.Name)

	// パブリッシュ
	if token := client.Publish(action.Name, byte(0), false, string(msg.Payload())); token.Wait() && token.Error() != nil {
		err := token.Error()
		fmt.Println(err)
		return err
	} else {
		client.Disconnect(250)
		return nil
	}
}

// ストレージ・サービスへのメッセージ保存
func saveMessage(action Action, msg MQTT.Message, file_id uint64) error {

	target_url := action.Target + action.Name + "/" + msg.Topic() + "/"

	if file_id == 0 {
		// ファイル名はタイムスタンプにする
		target_url = target_url + strconv.FormatInt(time.Now().UnixNano(), 10)
	} else {
		//  ファイル名は通し番号にする
		target_url = target_url + strconv.FormatUint(file_id, 10)
	}

	fmt.Println("saveMessage", msg.Topic(), "->", target_url)

	// PUTで保存
	req, err := http.NewRequest("PUT", target_url, strings.NewReader(string(msg.Payload())))
	if err != nil {
		log.Println("http.NewRequest Failed:", err)
		return err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	client := &http.Client{}
	res, err := client.Do(req)
	if err != nil {
		log.Println("client.Do Failed:", err)
	} else {
		defer res.Body.Close()
	}
	return err
}

// MQTTメッセージハンドラ
func messageHandler(client MQTT.Client, msg MQTT.Message) {
	if debug_mode {
		fmt.Println("start messageHandler")
		fmt.Printf("RECEIVED TOPIC: %s MESSAGE: %s\n", msg.Topic(), string(msg.Payload()))
	}
	switch actions[msg.Topic()].Action {
	case ACTION_SAVE:
		if fileid_mode {
			FileID[msg.Topic()] = FileID[msg.Topic()] + 1
			saveMessage(actions[msg.Topic()], msg, FileID[msg.Topic()])
		} else {
			saveMessage(actions[msg.Topic()], msg, FileID[msg.Topic()])
		}
	case ACTION_PUBLISH:
		publishMessage(actions[msg.Topic()], msg)
	}
}

//コネクション切断時のコールバック
func connectionLost(client MQTT.Client, e error) {

	if debug_mode {
		fmt.Println("connectionLost:", client, e)
	}

	stopCollector(client)
	go startCollector(conf)
    
}

func stopCollector(client MQTT.Client) {
	if debug_mode {
		fmt.Println("stopCollector:", client)
	}
	//client.Disconnect(250)
	fmt.Println("stopCollector: write cmd_chan")
	cmd_chan <- "quit"
	fmt.Println("stopCollector: write cmd_chan done")
//	if client.IsConnected() {
	if client != nil {
		if debug_mode {
			fmt.Println("stopCollector: read fin_chan")
		}
		_ = <-fin_chan
	}
	if debug_mode {
		fmt.Println("stopCollector END:", client)
	}
}

// データ収集処理の開始
func startCollector(conf *Config) MQTT.Client {
	if debug_mode {
		fmt.Println("startCollector:", conf)
	}

	mqtt_client = MQTT.Client(nil)

	// MQTTクライアントの準備
	opts := MQTT.NewClientOptions()
	broker := "tcp://" + conf.Broker_host + ":" + strconv.FormatInt(int64(conf.Broker_port), 10)
	opts.AddBroker(broker)
	opts.SetClientID("Message Collector")
	opts.SetCleanSession(false)
	opts.SetAutoReconnect(false)
	opts.SetConnectionLostHandler(connectionLost)

	client := MQTT.NewClient(opts)
	// MQTT Brokerへ接続
	var token MQTT.Token
	retry_max := conf.RetryMax
	if retry_max == 0 {
	   retry_max = math.MaxInt32
	}
	for retry_cnt := 0 ;; {
	    if token = client.Connect(); token.Wait() && token.Error() == nil {
	    	if debug_mode {
	    	   fmt.Println("startCollector: MQTT client setup complete")
		}
	       break
	    }
	    
	    if retry_cnt == retry_max {
	       fmt.Println("startCollector: MQTT client setup failed")
	       return nil
	    }
	    if debug_mode {
		fmt.Println("startCollector: MQTT client setup error and retry. Sleep ", conf.RetryInterval, "seconds.")
		}
	    // wait
	    time.Sleep(time.Duration(conf.RetryInterval) * time.Second)
	    
	    // counter
	    retry_cnt++
	}
	
	topic := make(map[string]byte)
	for _, action := range conf.Actions {
		// 収集対象のトッピクを設定
		topic[action.Topic] = byte(0)
		// 各トピックに対する処理を設定
		actions[action.Topic] = action
		FileID[action.Topic] = 0 // 本当は保存先に存在する最後の番号以降のものをつ合わないとダメ
	}

	if debug_mode {
		fmt.Println(topic)
	}

	// サブスクライバーを準備してメッセージを待つ
	token = client.SubscribeMultiple(topic, messageHandler)
	token.Wait()

	mqtt_client = client

	// 終了通知まで寝てる
	select {
	case cmd := <-cmd_chan:
		// cmd判定で処理を変えることもできるが、今は終了のみなので判定しない
		fmt.Println(cmd)
		fmt.Println("stop startCollector", conf)
		break
	}

	// 切断
	client.Disconnect(250)

	// 処理が終了したことを報告する
	fmt.Println("fin_chan <- \"fin\"")
	fin_chan <- "fin"

	if debug_mode {
		fmt.Println("startCollector END:", conf, client)
	}
	return nil
}

// リクエストハンドラ：バージョン返却
func requestHandler(c echo.Context) error {
	return c.String(http.StatusOK, "IoT Message Collector Ver0.5")
}

// リクエストハンドラ：プログラムコントロール
func controlHandler(c echo.Context) error {
	if debug_mode {
		fmt.Println("control handler")
	}
	// コマンド名取得
	cmd := c.FormValue("command")
	// コマンド毎の処理
	switch cmd {
	case CMD_QUIT: // プログラムの終了
		if debug_mode {
			fmt.Println(CMD_QUIT)
		}
		stopCollector(mqtt_client)
		//if mqtt_client != nil {
		//	fmt.Println("MQTT disconnect")
		//	mqtt_client.Disconnect(250)
		//}
		// プログラム終了通知
		srv_fin_chan <- "fin"
	}
	return c.NoContent(http.StatusOK)
}

// メイン処理
func main() {

	// プログラム配置場所のTOPを取得
	myserver_root = os.Getenv("MYSERVER_ROOT")
	fmt.Println("MYSERVER_ROOT = ", myserver_root)

	// オプション解析
	opt_config := flag.String("config", "./config.json", "config file path.")
	flag.Parse()

	// 設定ファイルを読み込む
	config_path := *opt_config
	if config_path == "" {
		prog_dir := filepath.Dir(os.Args[0])
		config_path = filepath.Join(prog_dir, "config.json")
	}
	log.Println("config file:", config_path)
//	conf := new(Config)
	conf_file, err := ioutil.ReadFile(config_path)
	if err != nil {
		log.Println("Config file read error.")
		os.Exit(1)
	}
	err = json.Unmarshal(conf_file, conf)
	log.Println(err)
	if err != nil {
		log.Println("Config file parse error.")
		os.Exit(1)
	}
	if debug_mode {
		log.Println("conf = ", *conf)
	}

	// 設定ファイルに値がない場合デフォルト値を使う
	if conf.Host == "" {
		conf.Host = HOST
	}
	if conf.Port == 0 {
		conf.Port = PORT
	}
	if conf.Broker_host == "" {
		conf.Broker_host = BROKER_HOST
	}
	if conf.Broker_port == 0 {
		conf.Broker_port = BROKER_PORT
	}
	if conf.Control_url == "" {
		conf.Control_url = CONTROL_URL
	}
	if debug_mode {
		log.Println("conf = ", *conf)
	}

	/*** データ収取処理の起動 ***/
//	mqtt_client = startCollector(conf)
//	if debug_mode {
//		log.Println("mqtt_client = ", mqtt_client)
//	}
//	if mqtt_client == nil {
//		fmt.Println("Failed to subscribe")
//		//os.Exit(1)
//	}
	go startCollector(conf)

	/*** コントロール用のAPIサーバ初期化 ***/
	// Echoセットアップ
	e := echo.New()

	// アクセスログの設定
	e.Use(middleware.Logger())

	// エラー発生時の対処設定
	e.Use(middleware.Recover())

	// ブラウザからjavascriptを使ってAPI呼び出しできるようにCORS対応
	e.Use(middleware.CORSWithConfig(middleware.CORSConfig{
		AllowOrigins: []string{"*"},
		AllowMethods: []string{echo.GET, echo.PUT, echo.POST, echo.DELETE, echo.HEAD},
	}))

	// リクエストハンドラ登録
	e.GET("/", requestHandler)
	e.POST(conf.Control_url, controlHandler)

	// サーバの起動
	go e.Start(conf.Host + ":" + strconv.FormatInt(int64(conf.Port), 10))

	// プログラム終了通知を待つ
	_ = <-srv_fin_chan

	// 処理停止
	ctx, cancel_fn := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel_fn()
	e.Shutdown(ctx)
}
