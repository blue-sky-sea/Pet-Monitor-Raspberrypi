/*
 MessegeDistributor

 メッセージ定期配信プログラム
*/

package main

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
	"context"
	"flag"

	MQTT "github.com/eclipse/paho.mqtt.golang"

	"github.com/labstack/echo"
	"github.com/labstack/echo/middleware"
)

const (
	CMD_QUIT         = "quit"
	ACTION_TYPE_MQTT = "MQTT"
	ACTION_TYPE_POST = "POST"
	ACTION_MODE_DIFF = "diff"
)

// 変数定義
var (
	myserver_root = "./"
	srv_fin_chan      = make(chan string, 1)
	debug_mode    = false
)

// 設定
type Action struct {
	Storage string `json:"storage"`
	Folder  string `json:"folder"`
	Cycle   int    `json:"cycle"`
	Mode    string `json:"mode"`
	Type    string `json:"type"`
	Target  string `json:"target"`
	Name    string `json:"name"`
}
type Config struct {
	Host        string   `json:"host"`
	Port        uint16   `json:"port"`
	Control_url string   `json:"control_url"`
	Actions     []Action `json:actions`
}

// ストレージ・サービスからメッセージを取り出す
func getMessage(storageService string, file string) string {
	target_url := storageService + file
	log.Println("getMessage", target_url)

	// GETでデータ取得する準備
	req, err := http.NewRequest("GET", target_url, nil)
	if err != nil {
		log.Println("http.NewRequest Failed:", err)
		return ""
	}
	client := &http.Client{}

	// データ取得
	res, err := client.Do(req)
	if err != nil {
		log.Println("client.Do Failed:", err)
		return ""
	}
	defer res.Body.Close()
	if res.StatusCode != 200 {
		msg, _ := ioutil.ReadAll(res.Body)
		log.Println("client returns error:", string(msg))
		return ""
	}

	// 取得したデータを取り出す
	data, err := ioutil.ReadAll(res.Body)

	return string(data)
}

type FileList struct {
	Files []string `json:"files"`
}

// ストレージ・サービスからファイル一覧を取得
func getFileList(storageService string, folder string, cur int64) []string {
	target_url := storageService + "?format=json"  // JSON形式でデータ取得
	if cur > 0 {
		// YYYYMMDDhhmmss形式で時刻を指定する
		tm := time.Unix(cur, 0)
		target_url = target_url + "&current_time=" + tm.Format("20060102150405")
	}
	log.Println("getMessage", target_url)

	// GETでデータ取得する準備
	req, err := http.NewRequest("GET", target_url, nil)
	if err != nil {
		log.Println("http.NewRequest Failed:", err)
		return []string{}
	}
	client := &http.Client{}

	// データ取得
	res, err := client.Do(req)
	if err != nil {
		log.Println("client.Do Failed:", err)
		return []string{}
	}
	defer res.Body.Close()
	if res.StatusCode != 200 {
		msg, _ := ioutil.ReadAll(res.Body)
		log.Println("client returns error:", string(msg))
		return []string{}
	}

	// 取得したデータを取り出す
	data, err := ioutil.ReadAll(res.Body)

	msg := ([]byte)(data)
	files := new(FileList)
	if err = json.Unmarshal(msg, files); err != nil {
		log.Println("FileList Unmarshal failed. - ", err)
		return []string{}
	}
	if debug_mode {
		log.Println(files.Files)
	}
	results := []string{}
	for _, f := range files.Files {
		if strings.HasPrefix(f, folder) {
			results = append(results, f)
		}
	}

	return results
}

// MQTTパブリッシュ処理
func publishMessage(broker string, topic string, message string) {
	log.Println("publishMessage", "->", "tcp://"+broker, topic, message)

	// 送信準備
	opts := MQTT.NewClientOptions()
	opts.AddBroker("tcp://" + broker)
	opts.SetClientID("Message Distributor")
	opts.SetCleanSession(false)

	if debug_mode {
		log.Println(opts)
	}
	client := MQTT.NewClient(opts)
	if token := client.Connect(); token.Wait() && token.Error() != nil {
		log.Println("publishMessage: MQTT client setup failed")
		return
	}

	// パブリッシュ
	if token := client.Publish(topic, byte(0), false, message); token.Wait() && token.Error() != nil {
		err := token.Error()
		log.Println(err)
	} else {
		client.Disconnect(250)
	}
	return
}

func requestHTTP(cmd string, url string, data interface{}) ([]byte, error) {
	log.Println("requestHTTP:", cmd, url)

	msg := ""
	if data != nil {
		msg = data.(string)
	}

	req, err := http.NewRequest(cmd, url, bytes.NewBuffer([]byte(msg)))
	if err != nil {
		log.Println("http.NewRequest Failed:", err)
		return nil, err
	}

	client := &http.Client{}
	res, err := client.Do(req)
	if err != nil {
		log.Println("client.Do Failed:", err)
		return nil, err
	} else {
		defer res.Body.Close()
		// 取得したデータを取り出す
		body, err := ioutil.ReadAll(res.Body)
		return body, err
	}
}

func post(url string, data interface{}) error {
	_, err := requestHTTP("POST", url, data)
	return err
}

func distributor(action Action) {
	log.Println("Start distributor:", action)
	// 処理ループ
	tm_next := time.Unix(0, 0)
	for {
		if debug_mode {
			log.Println("DO: ", action)
		}
		tm := tm_next
		/* 差分モードの場合は、指定時刻以降に更新されたもののみリストアップする。
		   そうでない場合は、全部リストアップする */
		if action.Mode == ACTION_MODE_DIFF {
			tm_next = time.Now()
		}
		// メッセージを読み込む
		file_list := getFileList(action.Storage, action.Folder, tm.Unix())
		if debug_mode {
			log.Println("file_list=", file_list)
		}
		for _, f := range file_list {
			if debug_mode {
				log.Println("f =", f)
			}
			msg := getMessage(action.Storage, f)
			if debug_mode {
				log.Println("msg =", string(msg))
			}
			if action.Type == ACTION_TYPE_MQTT { // MQTT
				publishMessage(action.Target, action.Name, msg)
			} else if action.Type == ACTION_TYPE_POST { // HTTP(POST)
				post(action.Target, msg)
			}
		}

		// 指定時間待ち合わせる
		cycle := 1
		if action.Cycle > 0 {
			cycle = action.Cycle
		}
		time.Sleep(time.Duration(cycle) * time.Second)
	}
}

// リクエストハンドラ：バージョン返却
func requestHandler(c echo.Context) error {
	return c.String(http.StatusOK, "IoT Message Distributor Ver0.5")
}

// リクエストハンドラ：プログラムコントロール
func controlHandler(c echo.Context) error {
	if debug_mode {
		log.Println("control handler")
	}
	// コマンド名取得
	cmd := c.FormValue("command")
	// コマンド毎の処理
	switch cmd {
	case CMD_QUIT: // プログラムの終了
		if debug_mode {
			log.Println(CMD_QUIT)
		}
		// プログラム終了通知
		srv_fin_chan <- "fin"
	}
	return c.NoContent(http.StatusOK)
}

// メイン処理
func main() {

	// プログラム配置場所のTOPを取得
	myserver_root = os.Getenv("MYSERVER_ROOT")
	log.Println("MYSERVER_ROOT = ", myserver_root)

	// オプション解析
	opt_config := flag.String("config", "./config.json", "config file path.")
	flag.Parse()

	// 設定ファイルを読み込む
	config_path := *opt_config
	if config_path == "" {
		prog_dir := filepath.Dir(os.Args[0])
		config_path = filepath.Join(prog_dir, "config.json")
	}
	log.Println("config file:", config_path)
	conf := new(Config)
	conf_file, err := ioutil.ReadFile(config_path)
	if err != nil {
		log.Println("Config file read error. - ", err)
		os.Exit(1)
	}
	err = json.Unmarshal(conf_file, conf)
	log.Println(err)
	if err != nil {
		log.Println("Config file parse error.")
		os.Exit(1)
	}
	if debug_mode {
		log.Println("conf = ", *conf)
	}

	// メッセージの定期配信処理の開始
	for _, action := range conf.Actions {
		if debug_mode {
			log.Println("action = ", action)
		}
		// Goルーチンで処理毎のスレッドを起動
		if action.Type == ACTION_TYPE_MQTT || action.Type == ACTION_TYPE_POST {
			go distributor(action)
		}
	}

	// Echoセットアップ
	e := echo.New()

	// アクセスログの設定
	e.Use(middleware.Logger())

	// エラー発生時の対処設定
	e.Use(middleware.Recover())

	// ブラウザからjavascriptを使ってAPI呼び出しできるようにCORS対応
	e.Use(middleware.CORSWithConfig(middleware.CORSConfig{
		AllowOrigins: []string{"*"},
		AllowMethods: []string{echo.GET, echo.PUT, echo.POST, echo.DELETE, echo.HEAD},
	}))

	// リクエストハンドラ登録
	e.GET("/", requestHandler)
	e.POST(conf.Control_url, controlHandler)

	// サーバの起動
	go e.Start(conf.Host + ":" + strconv.FormatInt(int64(conf.Port), 10))

	// プログラム終了通知を待つ
	_ = <-srv_fin_chan

	// 処理停止
	ctx, cancel_fn := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel_fn()
	e.Shutdown(ctx)
}
