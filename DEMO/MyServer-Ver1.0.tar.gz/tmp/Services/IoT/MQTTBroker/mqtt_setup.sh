#!/bin/bash


# 使用するErlangのバージョンを指定する
OTPVER=23.2

MYSERVER_TOP=$1

if [ "x$MYSERVER_TOP" = "x" ]
then
    exit 1
fi

. $MYSERVER_TOP/TOOLS/SETUP/env

if [ -x $MYSERVER_TOP/$SRVTOP/IoT/MQTTBroker/otp_src_${OTPVER}/bin/erl ]; then
    echo "Already installed Erlang"
else
    echo "Installing Erlang. This may take long time. Please Wait..."
    echo "  - downloading Erlang..."
    # Erlang
    FILE=otp_src_${OTPVER}.tar.gz
    URL=http://erlang.org/download/$FILE
    DIR=otp_src_${OTPVER}

    pushd $MYSERVER_TOP/download
    wget -nc -q $URL
    popd

    echo "  - installing development package..."
    pushd $MYSERVER_TOP/$SRVTOP/IoT/MQTTBroker
    $SUDO apt-get update
    $SUDO apt-get install -y libncurses5-dev
    $SUDO apt-get install -y libssl-dev

    echo "  - building Erlang..."
    rm -rf $DIR
    tar zxf $MYSERVER_TOP/download/$FILE
    pushd $DIR
    export ERL_TOP=`pwd`
    ./configure >& erlang_configure.log
    export LANG=C
    make >& erlang_make.log
    $SUDO make install >& erlang_install.log
    popd
    popd
fi


# EMQ
pushd $MYSERVER_TOP/$SRVTOP/IoT/MQTTBroker
if [ -x emq-relx/_build/emqx/rel/emqx/bin/emqx ]; then
    echo "Already built emqx"
elif [ -x emq-relx/_rel/emqx/bin/emqx ]; then
    echo "Already built emqx"
else
    echo "Building emqx..."
    git clone https://github.com/emqtt/emq-relx.git
    cd emq-relx
    make >& emq_make.log
fi
popd
