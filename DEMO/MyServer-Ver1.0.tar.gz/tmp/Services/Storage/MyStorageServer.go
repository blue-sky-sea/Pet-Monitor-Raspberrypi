/*
 MyStorageServer
   Storage Service
*/
package main

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"strconv"
	"strings"
	"time"
	"context"
	"flag"

	"./Manager"
	"./Remote"
	"./Storage"
	"github.com/labstack/echo"
	"github.com/labstack/echo/middleware"
)

const (
	USER_SERVICE      = "/user/"
	STORAGE_SERVICE   = "/storage/"
	STORAGE_DATA_BASE = "./Storage/DATA"
	HOST              = "localhost"
	PORT              = uint16(3000)
	FILE_SIG          = ".MYSSRV."
	CONTROL_URL	  = "/control"
	CMD_QUIT = "quit"
)

var (
	manager  *Manager.Manager
	remote   *Remote.Replication
	data_dir = STORAGE_DATA_BASE

	overwrite         = true
	debug_mode        = true
	replication_async = true

	myserver_root = "./"
	log_dir = "./"
	events        = map[string]string{}

	srv_fin_chan      = make(chan string, 1)
)

func requestHandler(c echo.Context) error {
	return c.String(http.StatusOK, "My Storage Server Ver1.0")
}

/*
　ファイル一覧をHTMLで返すための応答データ作成
*/
func htmlList(list []string, base string) string {
	html_head := "<html><head><title>Myサーバー ファイル一覧</title></head><body><H>サーバー上のファイル一覧</H><br><ul>"
	html_tail := "</ul></body></html>"
	html_list := ""

	for _, file := range list {
		if debug_mode {
			fmt.Println(file)
		}
		// HTML li要素で連結
		html_list += "<li><A HREF=\"" + base + file + "\">" + file + "</A></li>"
	}

	if debug_mode {
		fmt.Println(html_list)
	}
	return html_head + html_list + html_tail
}

/*
 ストレージ・サーバに保存されているファイル一覧を取得するI/F
*/
func listFiles(c echo.Context) error {

	if debug_mode {
		fmt.Println("list files")
	}
	// URLからフォルダのパスを組み立てる
	file_name := c.Request().URL.Path
	file_path, _, err := filePath(file_name, false)
	if debug_mode {
		fmt.Println("file_path =", file_path)
	}
	if err != nil {
		file_path = data_dir
	}

	// パラメータ(current_time)を取得する
	current_time := c.QueryParam("current_time")
	if debug_mode {
		fmt.Println("current_time = ", current_time)
	}
	// パラメータは YYYYMMDDhhmmssとする
	var t time.Time
	if len(current_time) == 14 {
		Y, _ := strconv.ParseInt(current_time[0:4], 10, 32)
		M, _ := strconv.ParseInt(current_time[4:6], 10, 32)
		D, _ := strconv.ParseInt(current_time[6:8], 10, 32)
		h, _ := strconv.ParseInt(current_time[8:10], 10, 32)
		m, _ := strconv.ParseInt(current_time[10:12], 10, 32)
		s, _ := strconv.ParseInt(current_time[12:14], 10, 32)
		if debug_mode {
			fmt.Println(Y, M, D, h, m, s)
		}
		local, _ := time.LoadLocation("Local")
		t = time.Date(int(Y), time.Month(M), int(D), int(h), int(m), int(s), 0, local)
	} else {
		t = time.Unix(0, 0)
	}
	// プログラム変更なしで、htmlとJSON形式を切り替えられるように変更
	format := c.QueryParam("format")
	if debug_mode {
		fmt.Println("format = ", format)
	}
	
	sr := Storage.NewStorageResource(file_path)

	list := sr.FileList(t)

	if debug_mode {
		fmt.Println(list)
	}

	if strings.ToLower(format) == "json" {
		res := map[string][]string{
			"files": list,
		}
		return c.JSON(http.StatusOK, res)
	} else {
		res := htmlList(list, file_name)
		return c.HTML(http.StatusOK, res)
	}
}

/*
 URLからファイル名を組み立てる
*/
func filePath(file_name string, dir_check bool) (string, string, error) {
	if debug_mode {
		fmt.Println("file name = " + file_name)
	}

	file := strings.Replace(file_name, STORAGE_SERVICE, "", 1)
	if dir_check && strings.HasSuffix(file, "/") {
		// ファイル名が"/"で終わっていたらエラー
		return data_dir, "", echo.NewHTTPError(http.StatusBadRequest, "Invalid file name.")
	}
	if strings.Contains(file, "..") {
		// ファイル名に".."が存在すればエラー
		return data_dir, "", echo.NewHTTPError(http.StatusBadRequest, "Invalid file name.")
	}
	file = path.Clean(file)
	if file == "." {
		// ファイル名指定がないのでエラー
		return data_dir, "", echo.NewHTTPError(http.StatusBadRequest, "No file name specified.")

	}
	//return data_dir + "/" + file, file, nil
	return filepath.Join(data_dir, file), file, nil
}

/*
データを保存するファイル名を "フィル名 + タイムスタンプ" で組み立てる。
*/
func fileName(file_name string) string {
	return file_name + ".MYSSRV." + strconv.FormatInt(time.Now().UnixNano(), 10)
}

func linkFile(orgpath string, newpath string) error {
	// newpathの存在確認
	_, err := os.Stat(newpath)
	if err == nil {
		// 存在すれば消す。Symlinkはnameが既にあるとエラーとなる
		os.Remove(newpath)
		if err != nil {
			fmt.Println(" Failed to remove ", newpath, ":", err)
			return err
		}
	}

	// シンボリックリンクを張る
	err = os.Symlink(orgpath, newpath)
	if err != nil {
		fmt.Println(" Failed to link ", newpath, ":", err)
		return err
	}

	// リモートのシンボリックリンク作成(ln -sf)
	err = remote.LinkFileOnServers(orgpath, newpath, nil)
	if err != nil {
		fmt.Println(" Failed to link(remote) ", newpath, ":", err)
	}

	return nil
}

/*
file_nameの保存データファイル一覧([]string)を返す
その中で、自分が最新かどうか(bool)を返す
*/
func getRelatedFiles(file_name string, me string) ([]string, bool) {

	dir := filepath.Dir(file_name)
	if debug_mode {
		fmt.Println(dir)
	}
	list := make([]string, 0)
	young := true

	walk_fn := func(path string, info os.FileInfo, err error) error {
		if strings.HasPrefix(path, file_name+".MYSSRV.") {
			if info.Mode()&os.ModeSymlink == 0 {
				res := strings.Compare(path, me)
				if res != 0 {
					if res > 0 {
						young = false
					}
					list = append(list, path)
				}
			}
		}
		return nil
	}

	err := filepath.Walk(dir, walk_fn)
	if err != nil {
		fmt.Println("path walk error on " + dir)
		return nil, false
	}
	if debug_mode {
		fmt.Println(list)
	}

	return list, young
}

/*
 リストで渡されたファイルを削除する。
 同名のファイルをリモート・サーバからも削除する。
*/
func deleteFiles(files []string) error {

	for _, file := range files {
		if debug_mode {
			fmt.Println(" remove ", file)
		}
		err := os.Remove(file)
		if err != nil && !os.IsNotExist(err) {
			fmt.Println("Failed to remove ", file)
			return err
		}

		// リモートのファイル削除(rm -f)
		err = remote.DeleteFileFromServers(file, nil)
		if err != nil && !os.IsNotExist(err) {
			fmt.Println("Failed to remove(remote) ", file)
		}

	}
	return nil
}

/*
 ファイルをリネームする。
 リネーム処理は以下
 - リンク先の実体ファイル取得
 - シンボリックリンクファイル削除
 - 実体ファイルのリネーム
 - 新ファイル名でシンボリックリンクファイルの新規作成

*/
func renameFile(orgpath string, newpath string) error {

	if debug_mode {
		fmt.Println("Enter renameFile:", orgpath, newpath)
	}

	// ファイルが存在しない場合はエラー
	_, err := os.Stat(orgpath)
	if os.IsNotExist(err) {
		return echo.NewHTTPError(http.StatusNotFound, orgpath+" is not found.")
	}

	// 新ファイル名と同じファイルが存在する場合はエラー
	_, err = os.Stat(newpath)
	if !os.IsNotExist(err) {
		return echo.NewHTTPError(http.StatusConflict, newpath+" is already exist.")
	}

	// シンボリックリンク先のファイル名を取得
	link, err := os.Readlink(orgpath)
	if err != nil {
		fmt.Println(" Failed to get link of ", orgpath, ":", err)
		return err
	}
	if debug_mode {
		fmt.Println("link of ", orgpath, " is ", link)
	}

	// 実体ファイルは、ファイル名+ ".MYSSRV." +現在時刻(秒)なので、ファイル名部分を置換する
	save_file := strings.Replace(link, orgpath, newpath, 1)
	if debug_mode {
		fmt.Println("save_file = ", save_file)
	}

	/* ファイル名のリネーム処理
	     	-> シンボリックリンクファイル削除
		-> 実体ファイル名のリネーム
		-> 新しいファイル名でシンボリックリンクファイル作成
	*/

	// ディレクトリ作成
	dir := path.Dir(save_file)
	err = os.MkdirAll(dir, 0775)
	if err != nil {
		return err
	}

	// シンボリックリンクの削除
	err = os.Remove(orgpath)
	if err != nil && !os.IsNotExist(err) {
		fmt.Println("Failed to remove ", orgpath)
		return err
	}

	// 実体ファイル名を変更
	err = os.Rename(link, save_file)
	if err != nil {
		fmt.Println(" Failed to rename ", link, "->", save_file, ":", err)
		return err
	}

	// シンボリックファイルの作成
	os.Remove(newpath)
	err = os.Symlink(save_file, newpath)
	if err != nil {
		fmt.Println(" Failed to link ", newpath, ":", err)
		return err
	}

	/* リモート・サーバ側のファイル名のリネーム処理
	     	-> リモートでシンボリックリンクファイル削除
		-> リモートで実体ファイル名のリネーム
		-> リモートで新しいファイル名でシンボリックリンクファイル作成
	*/

	// リモートでディレクトリ作成
	err = remote.CreateDirectoryOnServers(dir, nil)
	if err != nil {
		fmt.Println("Failed to create directory. ", err)
	}

	// リモートでシンボリックリンクファイル削除
	err = remote.DeleteFileFromServers(orgpath, nil)
	if err != nil && !os.IsNotExist(err) {
		fmt.Println("Failed to remove(remote) ", orgpath)
	}
	// リモートで実体ファイル名のリネーム
	err = remote.RenameFileOnServers(link, save_file, nil)
	if err != nil {
		fmt.Println(" Failed to rename ", link, "->", save_file, ":", err)
		return err
	}
	// リモートで新しいファイル名でシンボリックリンクファイル作成
	err = remote.LinkFileOnServers(save_file, newpath, nil)
	if err != nil {
		fmt.Println(" Failed to link(remote) ", newpath, ":", err)
	}

	return nil
}

/*
 ファイルを保存する。
 ファイルはリモート・サーバにもコピーする。
*/
func saveFile(rf io.Reader, file_path string) error {

	if debug_mode {
		fmt.Println("saveFile")
	}

	// ディレクトリ作成
	dir := path.Dir(file_path)
	err := os.MkdirAll(dir, 0775)
	if err != nil {
		fmt.Println("Failed to create directory. ", err)
		return err
	}

	/*
	   ファイル名+ ".MYSSRV." +現在時刻(秒)で実体を書き込む
	   リモートにも同盟で書き込む
	   シンボリックリンクを更新
	   　　　シンボリックリンク作成時点で最新のものにリンクを張る
	   　　　古いものは削除する。世代管理を導入した場合一定数は残すようにする
	*/
	save_file := fileName(file_path)
	if debug_mode {
		fmt.Println("save_file = ", save_file)
	}

	// ファイル作成
	wf, err := os.Create(save_file)
	if err != nil {
		fmt.Println("Failed to create file. ", err)
		return err
	}
	defer wf.Close()

	// Copy
	_, err = io.Copy(wf, rf)
	if err != nil {
		return err
	}

	// リモートへコピー(同期)
	// まずはディレクトリを作成する
	err = remote.CreateDirectoryOnServers(dir, nil)
	if err != nil {
		fmt.Println("Failed to create directory. ", err)
	}

	// コピー実施
	err = remote.CopyFileToServers(save_file, nil)
	if err != nil {
		fmt.Println("Failed to copy file. ", err)
	}

	// 関連ファイルの検索とリンク制御の判定
	files, need_link := getRelatedFiles(file_path, save_file)
	if debug_mode {
		fmt.Println("files = ", files)
	}
	if debug_mode {
		fmt.Println("need_link = ", need_link)
	}

	if need_link {
		// link new
		err = linkFile(save_file, file_path)
		if err != nil {
			fmt.Println("Failed to link. ", err)
			return err
		}
		// delete old
		err = deleteFiles(files)
		if err != nil {
			fmt.Println("Failed to delete files. ", err)
		}
	} else {
		// delete me
		list := []string{save_file}
		err = deleteFiles(list)
		if err != nil {
			fmt.Println("Failed to delete me. ", err)
		}
	}

	// イベント処理する
	prog, ok := events["create"]
	if ok {
		cmd := filepath.Join(myserver_root, prog)
		if debug_mode {
			fmt.Println("Call Create Event:", cmd)
		}
		err = exec.Command(cmd, data_dir, file_path).Start() // 非同期
	}

	if debug_mode {
		fmt.Println("saveFile exit")
	}
	return nil
}

/*
 ストレージ・サーバにファイルを保存するI/F
 既存ファイルは上書きされる
*/
func createFile(c echo.Context) error {
	if debug_mode {
		fmt.Println("create file")
	}

	// URLからファイル名を組み立てる
	name := c.FormValue("name")
	file_path, file_name, err := filePath(name, true)
	if err != nil {
		fmt.Println("filePath error. ", err)
		return err
	}

	if overwrite == false {
		_, err := os.Stat(file_path)
		if !os.IsNotExist(err) {
			return echo.NewHTTPError(http.StatusConflict, file_name+" is already exist.")
		}
	}

	// formから保存対象のファイルをオープンする
	file, err := c.FormFile("file")
	if err != nil {
		fmt.Println("FormFile error", err)
		return err
	}
	rf, err := file.Open()
	if err != nil {
		fmt.Println("open error:", file, err)
		return err
	}
	defer rf.Close()

	// ストレージにファイルを保存する
	err = saveFile(rf, file_path)
	if err != nil {
		return err
	}

	return c.NoContent(http.StatusOK)
}

/*
 ストレージ・サーバにファイルを保存するI/F
 既存ファイルは上書きされる
*/
func updateFile(c echo.Context) error {
	if debug_mode {
		fmt.Println("update file")
	}

	// URLからファイル名を組み立てる
	file_name := c.Request().URL.Path
	file_path, _, err := filePath(file_name, true)
	if err != nil {
		return err
	}

	// クエリからリネームかどうか判断する
	rename := c.QueryParam("rename")
	if rename != "" {
		if debug_mode {
			fmt.Println("rename request")
		}
		// 新ファイル名のパスを組み立てる
		newpath, _, err := filePath(rename, true)
		err = renameFile(filepath.Clean(file_path), filepath.Clean(newpath))
		if err != nil {
			return err
		} else {
			return c.NoContent(http.StatusOK)
		}
	}

	// リクエスト・ボディからデータを読み込む
	rf := c.Request().Body

	// ストレージにファイルを保存する
	err = saveFile(rf, file_path)
	if err != nil {
		return err
	}

	return c.NoContent(http.StatusOK)
}

/*
 ストレージ・サーバに保存されているファイルを読み出すI/F
*/
func readFile(c echo.Context) error {
	if debug_mode {
		fmt.Println("read file")
	}

	// URLからファイル名を組み立てる
	file_name := c.Request().URL.Path

	// 最後が '/' で終わっていたらファイル一覧取得処理に進む
	if strings.HasSuffix(file_name, "/") {
		return listFiles(c)
	}

	// ファイルパス名に変換する
	file_path, _, err := filePath(file_name, true)
	if err != nil {
		return err
	}

	// 存在チェック
	file_info, err := os.Stat(file_path)
	if os.IsNotExist(err) {
		// redirect another server
		srv := manager.AnotherApiServer(file_path)
		if srv != nil {
			if debug_mode {
				fmt.Println("redirect to ", "http://"+srv.Address()+file_name)
			}
			return c.Redirect(http.StatusTemporaryRedirect, "http://"+srv.Address()+file_name)
		} else {
			return echo.NewHTTPError(http.StatusNotFound, file_name+" is not found.")
		}
	}

	if debug_mode {
		size := file_info.Size()
		fmt.Printf("size of \"%s\" is %d\n", file_path, size)
	}

	// ファイル・データを送信
	return c.File(file_path)
}

/*
 ストレージ・サーバに保存されているファイルの属性情報を取得するI/F
 取得できる情報は、サイズと更新日時
*/
func infoFile(c echo.Context) error {
	if debug_mode {
		fmt.Println("info file")
	}

	// URLからファイル名を組み立てる
	file_name := c.Request().URL.Path
	file_path, _, err := filePath(file_name, true)
	if err != nil {
		return err
	}

	// 存在チェック
	file_info, err := os.Stat(file_path)
	if os.IsNotExist(err) {
		// redirect another server
		srv := manager.AnotherApiServer(file_path)
		if srv != nil {
			if debug_mode {
				fmt.Println("redirect to ", "http://"+srv.Address()+file_name)
			}
			return c.Redirect(http.StatusTemporaryRedirect, "http://"+srv.Address()+file_name)
		} else {
			return echo.ErrNotFound
		}

	}

	if debug_mode {
		fmt.Println(file_name)
		fmt.Println(file_info.Size())
		fmt.Println(file_info.ModTime())
	}

	c.Response().Header().Set(echo.HeaderLastModified, file_info.ModTime().Format(time.RFC1123))
	c.Response().Header().Set(echo.HeaderContentLength, strconv.FormatInt(file_info.Size(), 10))
	return c.NoContent(http.StatusOK)
}

/*
 ストレージ・サーバに保存されているファイルを削除するI/F
*/
func deleteFile(c echo.Context) error {
	if debug_mode {
		fmt.Println("delete file")
	}

	// URLからファイル名を組み立てる
	file_name := c.Request().URL.Path
	file_path, _, err := filePath(file_name, true)
	if err != nil {
		return err
	}

	err = os.Remove(file_path)
	if os.IsNotExist(err) {
		return echo.ErrNotFound
	}
	if err != nil {
		return err
	}

	// 関連ファイルとリモート側を消す
	files, _ := getRelatedFiles(file_path, file_path)
	if debug_mode {
		fmt.Println("files = ", files)
	}
	files = append(files, file_path)
	err = deleteFiles(files)
	fmt.Println("Failed to delete files. ", err)

	// 空になったらディレクトリも消す
	d := filepath.Dir(file_path)
	for {
		if d == data_dir {
			break
		}
		if debug_mode {
			fmt.Println("remove " + d)
		}
		err = os.Remove(d)
		if err != nil {
			if debug_mode {
				fmt.Println("failed to remove dir " + d)
			}
			break
		}
		// リモート側も消す
		err = remote.DeleteFileFromServers(d, nil)
		if err != nil {
			fmt.Println("Failed to remove dir(remote) ", d)
		}

		d = filepath.Dir(d)
	}

	// イベント処理する
	prog, ok := events["delete"]
	if ok {
		cmd := filepath.Join(myserver_root, prog)
		fmt.Println("Call Delete Event:", cmd)
		err = exec.Command(cmd, data_dir, file_path).Start() // 非同期
	}
	return c.NoContent(http.StatusOK)
}

// リクエストハンドラ：プログラムコントロール
func controlHandler(c echo.Context) error {
	if debug_mode {
		fmt.Println("control handler")
	}
	// コマンド名取得
	cmd := c.FormValue("command")
	// コマンド毎の処理
	switch cmd {
	case CMD_QUIT: // プログラムの終了
		if debug_mode {
			fmt.Println(CMD_QUIT)
		}
		// プログラム終了通知
		srv_fin_chan <- "fin"
	}
	return c.NoContent(http.StatusOK)
}

/*
 ストレージ・サーバのメイン処理
*/
func main() {

	fmt.Println("starting My Storage Server")

	// プログラム配置場所のTOPを取得
	wk := os.Getenv("MYSERVER_ROOT")
	if wk != "" {
		myserver_root = wk
	}

	// ログ出力準備
	wk = os.Getenv("MYSERVER_LOG")
	if wk != "" {
	   log_dir = wk
	}
	fmt.Println("MYSERVER_ROOT = ", myserver_root)
	fmt.Println("MYSERVER_LOG  = ", log_dir)

	// オプション解析
	opt_config := flag.String("config", "./config.json", "config file path.")
	flag.Parse()

	// 設定ファイルの読み込みパス決定
	config_path := *opt_config
	if config_path == "" {
		prog_dir := filepath.Dir(os.Args[0])
		config_path = filepath.Join(prog_dir, "config.json")
	}
	fmt.Println("config file:", config_path)

	//管理データ準備
	manager = new(Manager.Manager)
	err := manager.Config(config_path)
	if err != nil {
		fmt.Println("Failed to setup Management data.")
		return
	}
	manager.Setup()

	// リモート・ファイル操作の準備
	remote = Remote.NewReplication(manager)
	if debug_mode {
		fmt.Println(remote)
	}

	// 設定の読み込み
	me := manager.LocalApiHost()
	data_dir = path.Clean(manager.Data_store())
	replication_async = manager.Replication_async()
	for _, evt := range manager.Event() {
		events[evt.Action] = evt.Prog
	}

	if debug_mode {
		fmt.Println("me = ", me)
		fmt.Println("data_dir = ", data_dir)
		fmt.Println("replication_async = ", replication_async)
		fmt.Println("events = ", events)
	}

	// Echoセットアップ
	e := echo.New()

	// アクセスログの設定
	e.Use(middleware.Logger())

	// エラー発生時の対処設定
	e.Use(middleware.Recover())

	// ブラウザからjavascriptを使ってAPI呼び出しできるようにCORS対応
	e.Use(middleware.CORSWithConfig(middleware.CORSConfig{
		AllowOrigins: []string{"*"},
		AllowMethods: []string{echo.GET, echo.PUT, echo.POST, echo.DELETE, echo.HEAD},
	}))

	// ストレージ・サーバのリクエストハンドラ登録
	e.GET("/", requestHandler)
	e.POST(CONTROL_URL, controlHandler)
	e.GET(STORAGE_SERVICE, listFiles)
	e.POST(STORAGE_SERVICE, createFile)
	e.PUT(STORAGE_SERVICE+"*", updateFile)
	e.GET(STORAGE_SERVICE+"*", readFile)
	e.HEAD(STORAGE_SERVICE+"*", infoFile)
	e.DELETE(STORAGE_SERVICE+"*", deleteFile)

	// サーバの起動
	go e.Start(me.Host + ":" + strconv.FormatInt(int64(me.Port), 10))

	// プログラム終了通知を待つ
	_ = <-srv_fin_chan

	// 処理停止
	ctx, cancel_fn := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel_fn()
	e.Shutdown(ctx)
}
