package Storage

/*
import (
	"fmt"
	"os"
	"path"
	"path/filepath"
	"strings"
)
*/

var ()

/*

ストレージリソース管理

storage.goの置き換え、移行を簡単にするために、storage.goは破棄する。
内容が空のファイルで上書きする感じかな。


レプリケーション対応するための検討事項：
・実ファイルをIOするひと
・レプリケーションをするひと
・ファイル名とサーバーと実ファイルの対応管理をするひと
・レプリケーション状態を管理するひと


ファイル一覧管理をFSから切り離す。
メタサーバー or FSを切り替えられるように
　ファイル管理情報：
	ファイル名	外部公開のキー
	サイズ
	更新日時
	作成日時
	オーナー
	パーミッション
	チェックサム	->ファイルチェックに利用
	保存場所	ストレージサーバー + サーバ上のファイル名
			※ストレージ・サーバー上のファイル名はUUIDにする。
			※ストレージ・サーバーはIDかIP。サーバーが死んだあとデータの信頼性が確認できない場合はそのサーバー上のデータを不正と扱う

	※ファイルを自分が持っている場合と、別の人が持っている場合がある。
	　また同じファイルはレプリケーションされているので、自分がエラーだった場合は別の人にリクエストをパスする。
	　パスは、データを持ってきてからクライアントに送るか、リダイレクトするか？
	　->LBの挙動次第だな

	※FSの場合はinodeから取得

　ストレージ・サーバー管理情報
	サーバー名
	ID
	状態
			正常、不正、初期化、同期中、etc...


　※サーバー一覧は別途
　※ユーザー一覧は別途
	MySQLかな


*/

type LocalStorageResource struct {
	data_dir string
	list     []string
}

type StorageResourceV2 struct {
	meta_db string
	list    []string
}

type FileResource struct {
	local_fs bool
	list     []string
}

type ServerResource struct {
}

type UserResource struct {
}

type StorageServerResource struct {
}
