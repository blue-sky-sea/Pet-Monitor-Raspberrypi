/*
 ファイル保存領域のディレクトリをスキャンして一覧を作成する処理
*/

package Storage

import (
	"fmt"
	"log"
	"os"
	"path"
	"path/filepath"
	"strings"
	"time"
)

var (
	debug_mode = false
)

/*
 ファイル一覧を保持する構造体
*/
type StorageResource struct {
	list []string
	top  string
}

/*
 エントリが見つかった場合の処理
*/
func (s *StorageResource) walkFunc(last time.Time) filepath.WalkFunc {
	return func(path string, info os.FileInfo, err error) error {
		if debug_mode {
			log.Println(path, last)
		}
		if info.Mode()&os.ModeSymlink != 0 {
			// レプリケーション対応によりシンボリックリンクのみがユーザ指定のファイルなので、それだけ対象にする
			if debug_mode {
				log.Println("found file:", path, info.ModTime())
			}
			// 指定時間以降に更新されたもののみ返却対象とする
			if info.ModTime().Before(last) {
				if debug_mode {
					log.Println(path, "is not list.")
				}
			} else {
				p := strings.Replace(path, s.top, "", 1)
				s.list = append(s.list, p)
			}
		}
		return nil
	}

}

/*
 ファイル一覧を返す関数
*/
func (s *StorageResource) FileList(tm time.Time) []string {
	dir := s.top
	if debug_mode {
		fmt.Println("listing at " + dir)
	}

	//データディレクトリが存在しなければ作成する
	_, err := os.Stat(dir)
	if os.IsNotExist(err) {
		err = os.MkdirAll(dir, 0775)
		if err != nil {
			fmt.Println("failed to create directory: " + dir)
			return nil
		}
	}

	err = filepath.Walk(dir, s.walkFunc(tm))
	if err != nil {
		fmt.Println("path walk error on " + dir)
		return nil
	}
	if debug_mode {
		fmt.Println(s.list)
	}
	return s.list
}

/*
 ファイル一覧を管理するオブジェクトを生成する
*/
func NewStorageResource(dir string) *StorageResource {
	sr := new(StorageResource)
	sr.top = path.Clean(dir)
	sr.list = make([]string, 0, 10)
	return sr
}
