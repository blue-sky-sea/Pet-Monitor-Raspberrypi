package ServerManager

import (
	"fmt"
	"strconv"
)

var (
	debug_mode = false
)

type Server struct {
	Status string // 状態
	Host   string // ホスト名
	Port   uint16 // sshポート番号
	User   string // ユーザ名
	Passwd string // パスワード
}

/*
 サーバーにアクセスするためのアドレスを
    IPアドレス:ポート番号
 の文字列形式で返す
*/
func (s *Server) Address() string {
	if debug_mode {
		fmt.Println("Enter Server.Address()")
	}
	return s.Host + ":" + strconv.FormatUint(uint64(s.Port), 10)
}
