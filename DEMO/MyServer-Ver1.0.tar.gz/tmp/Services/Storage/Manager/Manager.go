/*
 システム管理パッケージ
*/

package Manager

import (
	"encoding/json"
	"fmt"
	"io/ioutil"

	"./ServerManager"
)

var (
	debug_mode = false
)

/* サーバー情報 */
type Server struct {
	ServerManager.Server
}

/*
 configファイルの情報を保持する構造体
*/
type Event struct {
	Action string `json:"action"`
	Prog   string `json:"prog"`
}

type Config struct {
	Servers           []Server `json:"servers"`
	Host              string   `json:"host"`
	Port              uint16   `json:"port"`
	User              string   `json:"user"`
	Password          string   `json:"password"`
	Replication_async bool     `json:"replication_async"`
	Data_store        string   `json:"data_store"`
	Meta_store        string   `json:"meta_store"`
	Api_host          string   `json:"api_host"`
	Api_port          uint16   `json:"api_port"`
	Html_list_mode    bool     `json:"html_list_mode"`
	Events            []Event  `json:"events"`
}

/*
 管理構造体
*/
type Manager struct {
	server_list []Server // システムの全サーバー情報のリスト
	config      Config   // 設定ファイル管理データ

	me          Server   // 自分のサーバー情報
	member_list []Server // 自分以外のサーバー情報のリスト
}

/*
 JSON形式のコンフィギュレーションファイルを読み込み、Config構造体に入る
*/
func (m *Manager) Config(config_path string) error {
	conf_file, err := ioutil.ReadFile(config_path)
	if err != nil {
		fmt.Println("Config file read error.")
		return err
	}
	err = json.Unmarshal(conf_file, &m.config)
	if debug_mode {
		fmt.Println(m.config)
	}
	return err
}

/*
 管理情報の初期化処理
*/
func (m *Manager) Setup() {
	if debug_mode {
		fmt.Println("Enter Manager.Setup()")
	}

	//　サーバーリストから自分を除いたメンバーリストを作成
	m.member_list = make([]Server, 0)
	for _, srv := range m.config.Servers {
		if srv.Host != m.config.Host || srv.Port != m.config.Port {
			m.member_list = append(m.member_list, srv)
		} else {
			m.me = srv
		}
	}
	if debug_mode {
		fmt.Println(" - m.member_list -")
		for _, srv := range m.member_list {
			fmt.Println(srv.Address())
		}
	}

	if debug_mode {
		fmt.Println("Exit Manager.Setup()")
	}
}

/*
 サーバーにアクセスするためのアカウント情報を返す
*/
func (m *Manager) Account() (string, string) {
	return m.config.User, m.config.Password
}

/*
 システムを構成するサーバー情報のリストを返す
*/
func (m *Manager) Servers() []Server {
	return m.server_list
}

/*
 自分から見てファイルをコピーするサーバーリストを取得
 ・正常に動作しているもの
 ・レプリケーション数に応じて適当に選んだサーバー
*/
func (m *Manager) ServersNeedSync() []Server {
	return m.member_list
}

/*
 指定ファイルが再レプリケーションが必要か確認し、
 必要な場合は、レプリケーション先のサーバーリストを返す
*/
func (m *Manager) ServersNeedReSync(file string) []Server {
	return m.member_list
}

/*
 自分以外でデータを持っているサーバーを返す
*/
func (m *Manager) AnotherApiServer(target string) *Server {

	if len(m.member_list) > 0 {
		/* 今は２台構成なのでもう一方を返す */
		return &m.member_list[0]
	} else {
		return nil
	}
}

/*
 自分のサーバー情報を返す
*/
func (m *Manager) LocalApiHost() *Server {
	return &Server{
		ServerManager.Server{Host: m.config.Api_host,
			Port:   m.config.Api_port,
			User:   m.config.User,
			Passwd: m.config.Password}}
}

/*
 自分のレプリケーション用のサーバー情報を返す
*/
func (m *Manager) LocalHost() *Server {
	return &Server{
		ServerManager.Server{Host: m.config.Host,
			Port:   m.config.Port,
			User:   m.config.User,
			Passwd: m.config.Password}}
}

/* 設定値のGetter */
//func (m *Manager) DataStore() string {
//	return m.config.Data_store
//}
func (m *Manager) Replication_async() bool {
	return m.config.Replication_async
}
func (m *Manager) Html_list_mode() bool {
	return m.config.Html_list_mode
}
func (m *Manager) Data_store() string {
	return m.config.Data_store
}
func (m *Manager) Event() []Event {
	return m.config.Events
}
