/*
 リモート処理パッケージ
*/

package Remote

import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/tmc/scp"
	"golang.org/x/crypto/ssh"

	"../Manager"
)

var (
	debug_mode = false
	ssh_port   = uint16(22)
	timeout    = 5 * time.Second
)

/*
 サーバー情報
*/
type Server struct {
	*Manager.Server
}

/*
 リモートサーバーへのファイル操作を管理するデータ構造
*/
type Replication struct {
	Servers []Server         // サーバー一覧
	User    string           // scp ユーザ
	Passwd  string           // scp パスワード
	manager *Manager.Manager // 管理情報へのポインタ
}

/*
 リモート処理の管理データを作成する
*/
func NewReplication(mgr *Manager.Manager) *Replication {
	rep := new(Replication)
	fmt.Println(rep)
	rep.manager = mgr
	return rep
}

/*
 リモートサーバー上でssh処理する
*/
func remoteRun(cmd string, copy bool, host string, port uint16, user string, passwd string) ([]byte, error) {
	if debug_mode {
		fmt.Println("enter RemoteRun()")
		fmt.Println("   cmd  = ", cmd)
		fmt.Println("   copy = ", copy)
		fmt.Println("   host = ", host)
		fmt.Println("   port = ", port)
		fmt.Println("   user = ", user)
		fmt.Println("   passwd = ", passwd)
	}

	// ssh 接続ユーザ設定
	ssh_config := &ssh.ClientConfig{
		User: user,
		Auth: []ssh.AuthMethod{
			ssh.Password(passwd),
		},
		Timeout: timeout,
	}

	// ssh接続
	client, err := ssh.Dial("tcp", host+":"+strconv.FormatUint(uint64(port), 10), ssh_config)
	if err != nil {
		fmt.Println("Failed to dial: ", err)
		return nil, err
	}
	// セッション作成
	session, err := client.NewSession()
	if err != nil {
		fmt.Println("Failed to create session: ", err)
		return nil, err
	}
	defer session.Close()

	// リモートサーバーでの操作
	out := []byte(nil)
	if copy {
		// scpでのファイル転送
		err = scp.CopyPath(cmd, cmd, session)
	} else {
		// sshでのコマンド実行
		out, err = session.Output(cmd)
	}
	if err != nil {
		fmt.Println("Failed to execute \"", cmd, "\" ", err)
	}

	if debug_mode {
		fmt.Println("exit RemoteRun()")
	}

	return out, err
}

/*
 sshでリモートサーバー上でコマンド実行する
*/
func RemoteExec(cmd string, host string, port uint16, user string, passwd string) ([]byte, error) {
	return remoteRun(cmd, false, host, port, user, passwd)
}

/*
 scpでリモートサーバーにファイルコピーする
*/
func RemoteCopy(target string, host string, port uint16, user string, passwd string) error {
	_, err := remoteRun(target, true, host, port, user, passwd)
	return err
}

/*
 ファイルを指定サーバーにコピーする
*/
func (r *Replication) CopyFileWithAuth(target string, host string, port uint16, user string, passwd string) error {
	if debug_mode {
		fmt.Println("enter CopyFileWithAuth: ", target)
	}

	// コピー元ファイルの更新日時を取得
	file_info, err := os.Stat(target)
	if os.IsNotExist(err) {
		return err
	}

	if debug_mode {
		fmt.Println(file_info)
	}

	// 指定サーバーにファイルをコピーする
	err = RemoteCopy(target, host, port, user, passwd)
	if err != nil {
		return err
	}

	// コピー先ファイルの更新日時をコピー元に合わせる
	cmd := "/usr/bin/touch -m -d \"" + file_info.ModTime().Format(time.RFC1123) + "\" " + target
	_, err = RemoteExec(cmd, host, port, user, passwd)
	if err != nil {
		fmt.Println("Failed to update file attribute.", err)
	}

	if debug_mode {
		fmt.Println("exit CopyFileWithAuth")
	}
	return nil
}

/*
 ファイルを指定されたサーバー群にコピーする
*/
func (r *Replication) CopyFileToServers(target string, wait chan bool) error {
	if debug_mode {
		fmt.Println("enter CopyFileToServers")
		fmt.Println("  target = ", target)
	}

	// コピー先サーバーとサーバーへアクセスるためのアカウントを取得
	servers := r.manager.ServersNeedSync()
	user, passwd := r.manager.Account()

	// 各サーバーにファイルをコピー
	err := make([]error, len(servers))
	var res error = nil
	for i, srv := range servers {
		err[i] = r.CopyFileWithAuth(target, srv.Host, ssh_port, user, passwd)
		if err[i] != nil {
			res = err[i]
		}
	}

	if debug_mode {
		fmt.Println(err)
	}

	if wait != nil {
		/*　チャネルに書き込む */
		wait <- true
	}

	if debug_mode {
		fmt.Println("exit CopyFileToServers")
	}

	return res
}

/*
 指定サーバーでファイルを削除する
*/
func (r *Replication) DeleteFileWithAuth(target string, host string, port uint16, user string, passwd string) error {
	if debug_mode {
		fmt.Println("enter DeleteFileWithAuth: ", target)
	}

	cmd := "/bin/rm -rf " + target
	_, err := RemoteExec(cmd, host, port, user, passwd)
	if err != nil {
		fmt.Println("Failed to delete file.", err)
	}

	if debug_mode {
		fmt.Println("exit DeleteFileWithAuth")
	}
	return err
}

/*
 指定されたサーバー群からファイルを削除する
*/
func (r *Replication) DeleteFileFromServers(target string, wait chan bool) error {

	if debug_mode {
		fmt.Println("enter DeleteFileFromServers()")
		fmt.Println("  target = ", target)
	}

	// サーバーとサーバーへアクセスるためのアカウントを取得
	servers := r.manager.ServersNeedSync()
	user, passwd := r.manager.Account()

	// 各サーバーでファイルを削除
	var res error = nil
	err := make([]error, len(servers))
	for i, srv := range servers {
		err[i] = r.DeleteFileWithAuth(target, srv.Host, ssh_port, user, passwd)
		if err[i] != nil {
			res = err[i]
		}
	}

	if debug_mode {
		fmt.Println(err)
	}
	if debug_mode {
		fmt.Println("exit DeleteFileFromServers()")
	}

	return res
}

/*
 指定サーバーでシンボリックリンクを作成する
*/
func (r *Replication) LinkFileWithAuth(orgpath string, newpath string, host string, port uint16, user string, passwd string) error {
	if debug_mode {
		fmt.Println("enter LinkFileWithAuth: ")
		fmt.Println("  " + newpath + " -> " + orgpath)
	}

	cmd := "/bin/ln -sf " + orgpath + " " + newpath
	_, err := RemoteExec(cmd, host, port, user, passwd)
	if err != nil {
		fmt.Println("Failed to link file.", err)
	}

	if debug_mode {
		fmt.Println("exit LinkFileWithAuth")
	}
	return err
}

/*
 指定されたサーバー群でシンボリックリンクを作成する
*/
func (r *Replication) LinkFileOnServers(orgpath string, newpath string, wait chan bool) error {

	if debug_mode {
		fmt.Println("enter LinkFileOnServers()")
	}

	// コピー先サーバーとサーバーへアクセスるためのアカウントを取得
	servers := r.manager.ServersNeedSync()
	user, passwd := r.manager.Account()

	// 各サーバーでシンボリックリンクを作成
	var res error = nil
	err := make([]error, len(servers))
	for i, srv := range servers {
		err[i] = r.LinkFileWithAuth(orgpath, newpath, srv.Host, ssh_port, user, passwd)
		if err[i] != nil {
			res = err[i]
		}
	}

	if debug_mode {
		fmt.Println(err)
	}
	if debug_mode {
		fmt.Println("exit LinkFileOnServers()")
	}

	return res
}

/*
 指定サーバーでディレクトリを作成する
*/
func (r *Replication) CreateDirectoryWithAuth(target string, host string, port uint16, user string, passwd string) error {
	if debug_mode {
		fmt.Println("enter CreateDirectoryWithAuth: ", target)
	}

	cmd := "/bin/mkdir -p " + target
	_, err := RemoteExec(cmd, host, port, user, passwd)
	if err != nil {
		fmt.Println("Failed to create directory.", err)
	}

	if debug_mode {
		fmt.Println("exit CreateDirectoryWithAuth")
	}
	return err
}

/*
 指定されたサーバー群でディレクトリを作成する
*/
func (r *Replication) CreateDirectoryOnServers(target string, wait chan bool) error {
	// コピー先サーバーとサーバーへアクセスるためのアカウントを取得
	servers := r.manager.ServersNeedSync()
	user, passwd := r.manager.Account()

	// 各サーバーでディレクトリを作成
	var res error = nil
	err := make([]error, len(servers))
	for i, srv := range servers {
		err[i] = r.CreateDirectoryWithAuth(target, srv.Host, ssh_port, user, passwd)
		if err[i] != nil {
			res = err[i]
		}
	}

	if debug_mode {
		fmt.Println(err)
	}

	return res
}

type RemFileInfo struct {
	name  string
	size  int64
	mtime time.Time
	mode  os.FileMode
	isDir bool
}

func (rfi *RemFileInfo) Name() string {
	return rfi.name
}
func (rfi *RemFileInfo) Size() int64 {
	return rfi.size
}
func (rfi *RemFileInfo) Mode() os.FileMode {
	return rfi.mode
}
func (rfi *RemFileInfo) ModTime() time.Time {
	return rfi.mtime
}
func (rfi *RemFileInfo) IsDir() bool {
	return false
}
func (rfi *RemFileInfo) Sys() interface{} {
	return nil
}

/*
   Name() string       // base name of the file
   Size() int64        // length in bytes for regular files; system-dependent for others
   Mode() FileMode     // file mode bits
   ModTime() time.Time // modification time
   IsDir() bool        // abbreviation for Mode().IsDir()
   Sys() interface{}   // underlying data source (can return nil)
*/

func (r *Replication) StatFileWithAuth(target string, host string, port uint16, user string, passwd string) (os.FileInfo, error) {
	if debug_mode {
		fmt.Println("enter StatFileWithAuth")
	}

	/*
	   コマンド例
	   $ /usr/bin/stat -L --printf=%s,%Y test_data2
	   4892944,1488941672
	   $
	   %s -> total size, in bytes
	   %Y -> time of last data modification, seconds since Epoch
	*/

	cmd := "/usr/bin/stat -L --printf=%s,%Y " + target

	out, err := RemoteExec(cmd, host, port, user, passwd)
	if err != nil {
		fmt.Println("Failed to stat file ", err)
	}
	if debug_mode {
		fmt.Println(out)
	}

	res := string(out)

	if debug_mode {
		fmt.Println(res)
	}

	/* 結果の整形 */
	s := strings.Split(res, ",")
	fmt.Println(s)

	size, err := strconv.ParseInt(s[0], 10, 64)
	if err != nil {
		fmt.Println("Failed to convert size")
		return nil, err
	}
	t, err := strconv.ParseInt(s[1], 10, 64)
	if err != nil {
		fmt.Println("Failed to convert time")
		return nil, err
	}

	fmt.Println("size = ", s[0], ", t = ", t)

	tm := time.Unix(t, 0)

	fmt.Println(tm)

	fi := new(RemFileInfo)
	fi.size = size
	fi.mtime = tm
	fmt.Println("exit StatFileWithAuth")
	return fi, nil

}

/*
 指定サーバーでファイルのリネームを行う
*/
func (r *Replication) RenameFileWithAuth(orgpath string, newpath string, host string, port uint16, user string, passwd string) error {
	if debug_mode {
		fmt.Println("enter RenameFileWithAuth: ", orgpath, newpath)
	}

	cmd := "/bin/mv -f " + orgpath + " " + newpath
	_, err := RemoteExec(cmd, host, port, user, passwd)
	if err != nil {
		fmt.Println("Failed to rename file.", err)
		return err
	}

	if debug_mode {
		fmt.Println("exit RenameFileWithAuth")
	}
	return err
}

/*
 指定されたサーバー群でファイルのリネームを行う
*/
func (r *Replication) RenameFileOnServers(orgpath string, newpath string, wait chan bool) error {

	if debug_mode {
		fmt.Println("enter RenameFileOnServers()")
		fmt.Println(orgpath, "->", newpath)
	}

	// サーバーとサーバーへアクセスるためのアカウントを取得
	servers := r.manager.ServersNeedSync()
	user, passwd := r.manager.Account()

	// 各サーバーでファイル名をリネーム
	var res error = nil
	err := make([]error, len(servers))
	for i, srv := range servers {
		err[i] = r.RenameFileWithAuth(orgpath, newpath, srv.Host, ssh_port, user, passwd)
		if err[i] != nil {
			res = err[i]
		}
	}

	if debug_mode {
		fmt.Println(err)
	}
	if debug_mode {
		fmt.Println("exit RenameFileOnServers()")
	}

	return res
}
