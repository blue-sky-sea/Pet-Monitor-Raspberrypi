package main

/*

環境変数で、MyServerのトップディレクトリを指定することにする。

MYSERVER_ROOT

それを使って、ファイルの場所などを見つけることにする。

*/

import (
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

var (
	myserver_root = "./"
	log_dir = "./"
	debug_mode    = true
)

/*
 configファイルの情報を保持する構造体
*/
type Action struct {
	Filter string `json:"filter"`
	Prog   string `json:"prog"`
}

type Config struct {
	Actions []Action `json:actions`
	Notify  string   `json:notify`
}

func main() {

	// プログラム配置場所のTOPを取得
	wk := os.Getenv("MYSERVER_ROOT")
	if wk != "" {
		myserver_root = wk
	}

	// ログ出力準備
	wk = os.Getenv("MYSERVER_LOG")
	if wk != "" {
	   log_dir = wk
	}
	fmt.Println("MYSERVER_ROOT = ", myserver_root)
	fmt.Println("MYSERVER_LOG  = ", log_dir)
	dir := filepath.Join(log_dir, "Event")
	_, err := os.Stat(dir)
	if os.IsNotExist(err) {
		err = os.MkdirAll(dir, 0775)
		if err != nil {
			fmt.Println("failed to create directory: " + dir)
			panic("cannnot create " + dir + " : " + err.Error())
		}
	}
	logfile, err := os.OpenFile(filepath.Join(dir, "file_event"),
		os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0666)
	if err != nil {
		panic("cannnot open file_event. " + err.Error())
	}
	defer logfile.Close()
	log.SetOutput(io.MultiWriter(logfile, os.Stdout))
	log.SetFlags(log.Ldate | log.Ltime)

	// 引数解析
	if len(os.Args) != 3 {
		log.Println("Usage: " + filepath.Base(os.Args[0]) + " <data store>> <file>")
		os.Exit(1)
	}
	data_store := os.Args[1]
	log.Println(data_store)
	file_name := os.Args[2]
	log.Println(file_name)

	// 設定ファイル
	prog_dir := filepath.Dir(os.Args[0])
	config_path := filepath.Join(prog_dir, "config.json")
	log.Println(config_path)

	// 設定ファイルを読み込む
	conf := new(Config)
	conf_file, err := ioutil.ReadFile(config_path)
	if err != nil {
		log.Println("Config file read error.")
		os.Exit(1)
	}
	err = json.Unmarshal(conf_file, conf)
	log.Println(err)
	if err != nil {
		log.Println("Config file parse error.")
		os.Exit(1)
	}
	if debug_mode {
		log.Println("conf = ", *conf)
	}

	// フィルタ条件にマッチした場合、設定に応じて外部プログラムを呼び出す
	for _, action := range conf.Actions {
		if debug_mode {
			log.Println("action = ", action)
		}
		filter := filepath.Join(data_store, action.Filter)
		if strings.HasPrefix(file_name, filter) {
			log.Println("Do Action:", action.Prog)
			cmd := filepath.Join(myserver_root, action.Prog)
			log.Println("  =>", cmd, data_store, file_name)
			err = exec.Command(cmd, data_store, file_name).Start() // 非同期
			log.Println(err)
			break
		}
	}

	// 通知イベント
	cmd := filepath.Join(myserver_root, conf.Notify)
	log.Println("  =>", cmd, data_store, file_name)
	err = exec.Command(cmd, data_store, file_name).Start() // 非同期
	log.Println(err)

}
