#!/bin/bash
#
# ペット見守りモニタ起動スクリプト
#

. ./myserver.env
. ./cmd
. ./goenv.sh
. ./nodeenv.sh
. ./pythonenv.sh


## MONITOR
if [ "$USE_PETWATCHER" = "YES" ];then
    pushd $MYSERVER_ROOT/PetWatcher/MONITOR

    if [ "$USE_MONITOR_DISTANCE" = "YES" ];then
	echo "Start distance.py"
	./distance.py &
    fi
    
    if [ "$USE_MONITOR_CAMERA" = "YES" ];then
	echo "Start picture.py"
	./picture.py &
    fi

    if [ "$USE_MONITOR_SENSOR" = "YES" ];then
	echo "Start sensor.py"
	./sensor.py &
    fi

    popd
fi

