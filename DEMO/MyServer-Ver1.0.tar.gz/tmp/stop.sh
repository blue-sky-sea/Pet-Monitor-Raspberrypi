#!/bin/bash
#
# Myサーバ停止スクリプト
#

. ./myserver.env
. ./cmd
. ./goenv.sh
. ./nodeenv.sh
. ./pythonenv.sh

function stop_request () {
    TARGET=$1
    curl -s -F "command=quit" ${TARGET}
}


# APP
## FileView
if [ "$USE_FILEVIEW" = "YES" ];then
    pid=`ps -af | grep node | grep 'fileview.js' | awk '{print($2)}'`
    if [ "x$pid" != "x" ]; then
	$SUDO kill -9 $pid
    fi
fi

# PetWatcher
## APP
if [ "$USE_PETWATCHER" = "YES" ];then
    pid=`ps -af | grep node | grep 'petwatcher.js' | awk '{print($2)}'`
    if [ "x$pid" != "x" ]; then
	$SUDO kill -9 $pid
    fi
fi


# IoT
if [ "$USE_IOT_AUTOMATE" = "YES" ];then
    #curl -s -F "command=quit" ${MYSERVER_IOT_AUTOMATE_URL}/control
    stop_request ${MYSERVER_IOT_AUTOMATE_URL}/control
fi
if [ "$USE_IOT_DISTRIBUTOR" = "YES" ];then
    # curl -s -F "command=quit" ${MYSERVER_IOT_DISTRIBUTOR_URL}/control
    stop_request ${MYSERVER_IOT_DISTRIBUTOR_URL}/control
fi
if [ "$USE_IOT_COLLECTOR" = "YES" ];then
    # curl -s -F "command=quit" ${MYSERVER_IOT_COLLECTOR_URL}/control
    stop_request ${MYSERVER_IOT_COLLECTOR_URL}/control
fi


# MQTT Broker
if [ "$USE_MQTT" = "YES" ];then
    pushd $MYSERVER_ROOT/Services/IoT/MQTTBroker
    if [ -x emq-relx/_build/emqx/rel/emqx/bin/emqx ]; then
	emq-relx/_build/emqx/rel/emqx/bin/emqx stop
    elif [ -x emq-relx/_rel/emqx/bin/emqx ]; then
	emq-relx/_rel/emqx/bin/emqx stop
    fi
    popd
fi


# LB
if [ "$USE_LB" = "YES" ];then
    echo "stop LB"
    $SUDO kill -USR1 $(cat $MYSERVER_ROOT/LB/haproxy.pid)
fi


# Storage Server
if [ "$USE_STORAGE" = "YES" ];then
    # curl -s -F "command=quit" ${MYSERVER_STORAGE_SERVER_1_URL}/control
    stop_request ${MYSERVER_STORAGE_SERVER_1_URL}/control
    if [ "x$MYSERVER_STORAGE_SERVER_2_URL" != "x" ]; then
	# curl -s -F "command=quit" ${MYSERVER_STORAGE_SERVER_2_URL}/control
	stop_request ${MYSERVER_STORAGE_SERVER_2_URL}/control
    fi
fi


