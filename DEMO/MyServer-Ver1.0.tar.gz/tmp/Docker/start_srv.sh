#!/bin/bash

# コンテナの起動スクリプト
# ボリュームの共有(./MyVolume -> /MyVolume)
#

HTTP_PORT=80
HTTPS_PORT=443
MQTT_PORT=1183
SSH_PORT=22

IFS=$'\n'
for rec in `grep -v ^# list`
do
    echo $rec
    no=`echo $rec | awk '{print($1)}'`
    name=`echo $rec | awk '{print($2)}'`
    image=`echo $rec | awk  '{print($3)}'`
    offset=`echo $rec | awk  '{print($4)}'`

    local_http_port=$((HTTP_PORT+offset))
    http="-p $local_http_port:$HTTP_PORT"
    local_https_port=$((HTTPS_PORT+offset))
    https="-p $local_https_port:$HTTPS_PORT"
    local_mqtt_port=$((MQTT_PORT+offset))
    mqtt="-p $local_mqtt_port:$MQTT_PORT"
    local_ssh_port=$((SSH_PORT+offset))
    ssh="-p $local_ssh_port:$SSH_PORT"

    docker run -d -t -i -v `pwd`/MyVolume:/MyVolume -h $name --name $name -p $local_http_port:$HTTP_PORT -p $local_https_port:$HTTPS_PORT -p $local_mqtt_port:$MQTT_PORT -p $local_ssh_port:$SSH_PORT $image
done

