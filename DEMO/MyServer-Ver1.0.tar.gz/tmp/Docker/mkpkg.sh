#!/bin/bash

DIST=$1

echo "Docker"

cp -pr * $DIST/
