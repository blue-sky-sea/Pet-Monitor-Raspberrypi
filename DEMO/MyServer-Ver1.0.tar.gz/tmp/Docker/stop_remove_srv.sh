#!/bin/bash

IFS=$'\n'
for rec in `grep -v ^# list`
do
    name=`echo $rec | awk '{print($2)}'`
    docker stop $name
    docker rm $name
done
