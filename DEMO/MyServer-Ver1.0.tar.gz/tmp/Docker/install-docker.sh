#!/bin/bash

mkdir -p DOWNLOAD

pushd DOWNLOAD
curl -fsSL https://get.docker.com -o get-docker.sh
popd

sh DOWNLOAD/get-docker.sh

sudo usermod -aG docker pi


