#!/usr/bin/env python
# -*- coding: utf-8 -*-

# jpeg画像をグレースケールに変換する
# 変換後のファイル名は、元ファイルのファイル名の前に "_mygs_" をつける。


# 変換は、OpenCVで行う

# OpenCVとpython-opencvのインストールが必要
# sudo apt-get install libopencv-dev
# sudo apt-get install python-opencv
# http://rabbitfoot141.hatenablog.com/entry/2016/02/05/235340 参照


import os.path
import sys
import cv2

debug_mode = True
PREFIX = '_mygs_'


# ストレージ・サービスのイベントは、保存ディレクトリ と ファイルパス　を引数にして呼び出される
if len(sys.argv) < 3:
    print('Usage: ' + os.path.basename(sys.argv[0]) + " <storage base> <file path>")
    sys.exit(1)

base_dir = sys.argv[1]
file = sys.argv[2]
if debug_mode:
    print(base_dir)
    print(file)


in_file = os.path.normpath(base_dir + '/' + file)
out_file = os.path.normpath(os.path.dirname(in_file) + '/' + PREFIX+os.path.basename(in_file))

if debug_mode:
    print(in_file)
    print(out_file)

pic = cv2.imread(in_file)
gs_pic = cv2.cvtColor(pic, cv2.COLOR_BGR2GRAY)
cv2.imwrite(out_file, gs_pic)

# 変換ファイルをストレージ・サービスに保存する




sys.exit(0)
