#!/bin/bash


# jpeg画像をグレースケールに変換する
# 変換後のファイル名は、元ファイルのファイル名の前に "_mygs_" をつける。

debug_mode=1

cmd=`basename $0`
if [ $# -lt 2 ] 
then
    echo "Usage: $cmd <storage base> <file path>"
    exit 1
fi


base_dir=$1
file=$2

PREFIX='_mygs_'

in_file="${base_dir%/}/${file#/}"

path_dir=`dirname $in_file`
path_file=`basename $in_file`
out_file="${path_dir%/}/$PREFIX${path_file#/}"

if [ $debug_mode = 1 ]
then
    echo $in_file
    echo $out_file
fi

# ImageMagik の convertコマンドで変換
convert $in_file -type GrayScale $out_file


# 変換ファイルをストレージ・サービスに保存する



exit 0