#!/bin/bash

MYSERVER_TOP=$1
AI_TOP=$2

if [ "x$MYSERVER_TOP" = "x" ]
then
    exit 1
fi


sudo apt-get install -y libopencv-dev
sudo apt-get install -y python-opencv
sudo apt-get install -y libffi-dev
sudo apt-get install -y libssl-dev

sudo pip install requests
sudo pip install paramiko
sudo pip install scp


ENVFILE=$MYSERVER_TOP/pythonenv.sh
echo "export MYSERVER_AI=${AI_TOP}" >> $ENVFILE
echo 'export PYTHONPATH=${MYSERVER_AI}/:$PYTHONPATH' >> $ENVFILE


