#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
import sys
import os
import json
import traceback
import MyServer.mystorage as MyStorage
import MyServer.common as MyCom
import VisionKit.visionkit as visionkit
'''
ライブラリをロードするために以下の環境変数設定が必要
export PYTHONPATH=$HOME/CQ/MyServer/LIB/python/:$HOME/CQ/MyServer/AI/:$PYTHONPATH
'''

# UTF-8エンコードにする
reload(sys)
sys.setdefaultencoding("utf-8")

# 引数解析
if len(sys.argv) < 3:
    print('Usage: classification.py <data store>> <file>')
    sys.exit(99)

cmd = sys.argv[0]
data_store = sys.argv[1]
file_name = sys.argv[2]
#コマンド配置ディレクトリを取得する
dir = os.path.dirname(cmd)

print(cmd)
print(data_store)
print(file_name)
print(dir)


try:
    # 設定ファイルのロード
    MyCom.load_config(os.path.join(dir, 'config.json'))
    f = open(os.path.join(dir, 'vk_config.json'), 'r')
    vk_conf = json.load(f)
    f.close()

    #ストレージ・サービスへのアクセス準備
    MyStorage.set_url(MyCom.storage())

    # Vision Kitへのアクセス準備
    vk = visionkit.VK(vk_conf['SSH_IP'], vk_conf['SSH_PORT'], vk_conf['SSH_USER'], vk_conf['SSH_PASSWD'])

    # 画像の識別
    res = vk.vk_recog_image(file_name, None)

    # kind->CAT,DOG,PERSON,その他
    if 'kind=CAT' in res:		## CAT ?
        kind = 'CAT'
    elif 'kind=DOG' in res:		## DOG ?
        kind = 'DOG'
    elif 'kind=PERSON' in res:	## PERSON ?
        kind = 'PERSON'
    else:				## その他
        kind = 'その他'
                

    # ファイルの移動
    f_name = file_name.replace(data_store, '') # file_name - data_store
    n_name = os.path.join('/', kind, *f_name.split('/'))
    print(f_name)
    print(n_name)
    MyStorage.rename(f_name, n_name)

except:
    print(traceback.format_exc())
    sys.exit(99)

